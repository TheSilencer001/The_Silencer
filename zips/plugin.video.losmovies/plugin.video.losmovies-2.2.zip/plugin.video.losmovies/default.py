import urllib,urllib2,re,xbmcplugin,xbmcgui,urlresolver,xbmc,xbmcaddon,os
from metahandler import metahandlers
from addon.common.addon import Addon
from addon.common.net import Net
import silent


#losmovies.com - by The_Silencer 2013 v2.1


grab = metahandlers.MetaData(preparezip = False)
addon_id = 'plugin.video.losmovies'
local = xbmcaddon.Addon(id=addon_id)
lospath = local.getAddonInfo('path')
addon = Addon(addon_id, sys.argv)
datapath = addon.get_profile()
art = lospath+'/art'
net = Net()
metaget = metahandlers.MetaData()
losurl = local.getSetting('url')


#Check URL Redirect at start up
def URLCHECK():
        setadd = losurl+'/'
        url = 'http://losmovies.com'
        r = urllib2.urlopen(url).geturl()
        redirect = r
        print setadd
        print redirect
        if setadd == redirect:
                CATEGORIES()
        else:
                addDir('LosMovies address has changed',losurl,16,os.path.join(art,''),None,None)
                addDir('Please change custom address in settings to:',losurl,17,os.path.join(art,''),None,None)
                addDir(redirect,losurl,17,os.path.join(art,''),None,None)
                addDir('Please dont add the / at the end of the url.',losurl,17,os.path.join(art,''),None,None)
                
#Main menu
def CATEGORIES():
        addDir('Movies',losurl,18,'',None,'')
        addDir('TV Shows',losurl,19,'',None,'')
        addDir('Search',losurl+'/search',15,'',None,'')
        addDir('Favorites',losurl,26,'',None,'')
        addDir('Settings',losurl,34,'',None,'')

def SETTINGS():
        addDir('Add-on Settings',losurl,35,'',None,'')
        addDir('Resolver Settings',losurl,36,'',None,'')
        addDir('Auto Start LosMovies','plugin.',37,'',None,'')

def MOVIES():
        addDir('Featured',losurl,39,'',None,'')
        addDir('New Releases',losurl+'/watch-new-release-movies',5,'',None,'')
        addDir('Latest',losurl+'/latest-movies',5,'',None,'')
        addDir('Most Popular',losurl,5,'',None,'')
        addDir('HD',losurl+'/watch-movies-in-hd',5,'',None,'')
        addDir('3D',losurl+'/watch-3D-movies',5,'',None,'')
        addDir('A-Z',losurl,10,'',None,'')
        addDir('Genres',losurl+'/movie-genres',9,'',None,'')
        addDir('Actors',losurl+'/actors',13,'',None,'')
        addDir('Directors',losurl+'/directors',14,'',None,'')
        addDir('Countries',losurl+'/countries',12,'',None,'')
        addDir('Search',losurl+'/search?',15,'',None,'')

def TVSHOWS():
        addDir('New Releases',losurl+'/watch-new-release-tv-shows',17,'',None,'')
        addDir('Latest',losurl+'/watch-latest-tv-shows',17,'',None,'')
        addDir('Most Popular',losurl+'/watch-popular-tv-shows',17,'',None,'')
        addDir('HD',losurl+'/watch-tv-shows-in-hd',17,'',None,'')
        addDir('A-Z',losurl+'/watch-popular-tv-shows',31,'',None,'')
        addDir('Genres',losurl+'/movie-genres',20,'',None,'')
        addDir('Actors',losurl+'/actors',13,'',None,'')
        addDir('Directors',losurl+'/directors',14,'',None,'')
        addDir('Countries',losurl+'/countries',21,'',None,'')
        addDir('Search',losurl+'/search',22,'',None,'')

def DIRECTORDIR():
        addDir('A-Z',losurl+'/directors',10,'',None,'')
        addDir('Search',losurl+'/search',38,'',None,'')

def ACTORSDIR():
        addDir('A-Z',losurl+'/actors',10,'',None,'')
        addDir('Search',losurl+'/search',16,'',None,'')

#Return Favorites List *temp need to fix in silent*
def GETMYFAVS():
        try:
                MYFAVS = silent.getFavorites()
                for name,url,types in MYFAVS:
                        addFAVDir(name,url,types)
        except:
                pass

#regex for countries movies
def COUNTRIES(url):
        match=re.compile('<img src="(.+?)" alt=".+?" title=".+?"/></div>.+?<div class="showRow showRowName showRowText">(.+?)</div>.+?<a href="(.+?)"  class="showRow showRowLinkMovies">',re.DOTALL).findall(net.http_GET(url).content)
        for iconimage,name,url in match:
                        addDir(name,losurl+url,5,iconimage,None,'')

#regex for Movie Collections
def COLLECTIONS(url):
        match=re.compile('<div class="showRow showRowImage showRowImage"><a href="(.+?)" ><img src="(.+?)" alt=".+?" title="Watch top (.+?)"/></a>',re.DOTALL).findall(net.http_GET(url).content)
        for url,iconimage,name in match:
                        addDir(name,losurl+url,5,iconimage,None,'')

#regex for countires tv shows
def COUNTRIESTV(url):
        match=re.compile('<img src="(.+?)" alt=".+?" title="(.+?)"/></div>.+?<div class="showRow showRowName showRowText">.+?</div>.+?<a href=".+?"  class=".+?">.+?</a>.+?<a href="(.+?)"  class="showRow showRowLinkTvShows">',re.DOTALL).findall(net.http_GET(url).content)
        for iconimage,name,url in match:
                        addDir(name,losurl+url,17,iconimage,None,'')

#regex for actors
def ACTORS(url):
        match=re.compile('<div class="showRow showRowImage showRowImage"><a href="(.+?)" ><img src="(.+?)" alt=".+?" title=".+?"/></a></div>.+?<h4 class="showRow showRowName showRowText">(.+?)</h4>',re.DOTALL).findall(net.http_GET(url).content)
        nextpage=re.search('<span class="currentStep">.+?</span><a href="(.+?)"',(net.http_GET(url).content))
        for url,iconimage,name in match:
                        name = silent.CLEAN(name)
                        addDir(name.encode('UTF-8','ignore'),losurl+url,5,iconimage,None,'')
        if nextpage:
                        url = nextpage.group(1)
                        url = url.replace('amp;','')
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',losurl+url,11,'',None,'')

#regex for Movie A-Z list
def MOVIEAZ(url):
        match=re.compile('<a href="(.+?)" class="letterFilter ">(.+?)</a>').findall(net.http_GET(url).content)
        for url,name in match:
                        if 'actors' in url:
                                nono = ['0', '1', '2', '3', '4', '6', '7', '8', '9']
                                if name not in nono:
                                        addDir(name,losurl+url,11,'',None,'')
                        elif 'directors' in url:
                                nono = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
                                if name not in nono:
                                        addDir(name,losurl+url,11,'',None,'')
                        else:
                                addDir(name,losurl+url,5,'',None,'')

#regex for TV A-Z list
def TVAZ(url):
        match=re.compile('<a href="(.+?)" class="letterFilter ">(.+?)</a>').findall(net.http_GET(url).content)
        for url,name in match:
                        addDir(name,losurl+url,17,'',None,'')

#regex for genres movies  
def MOVIEGEN(url):
        match=re.compile('<div class="showRow showRowName showRowText">(.+?)</div>.+?<a href="(.+?)"  class="showRow showRowLinkMovies">',re.DOTALL).findall(net.http_GET(url).content)
        for name,url in match:
                        addDir(name,losurl+url,5,'',None,'')

#regex for genres tv shows 
def TVGEN(url):
        match=re.compile('<div class="showRow showRowName showRowText">(.+?)</div>\n\t<a href=".+?"  class="showRow showRowLinkMovies">.+?</a>\n\t<a href="(.+?)"  class="showRow showRowLinkTvShows">',re.DOTALL).findall(net.http_GET(url).content)
        for name,url in match:
                        addDir(name,losurl+url,17,'',None,'')

#Routine to search for Movies
def SEARCH(url):
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search Movies from losmovies.es')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace('%20', ' ')
                print encode
                data = net.http_POST(url,{'type' : 'movies', 'q' : encode}).content
                match=re.compile('<div class="showRow showRowImage showRowImage"><a href="(.+?)" ><img src=".+?" alt=".+?" title="Watch (.+?) Online"/>',re.DOTALL).findall(data)  
                for url,name in match:
                        name = silent.CLEAN(name)
                        if EnableMeta == 'true':
                               addDir(name,losurl+url+'@'+name,6,'','Movie','')
                        if EnableMeta == 'false':
                               addDir(name,losurl+url+'@'+name,6,'',None,'')

#Routine to search for TV Shows
def SEARCHTV(url):
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search TV Shows from losmovies.es')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace('%20', ' ')
                print encode
                data = net.http_POST(url,{'type' : 'movies', 'q' : encode}).content
                match=re.compile('<div class="showRow showRowImage showRowImage"><a href="(.+?)" ><img src=".+?" alt=".+?" title="Watch (.+?) Online"/></a>').findall(data)  
                for url,name in match:
                        name = silent.CLEAN(name)
                        if EnableMeta == 'true':
                               addDir(name,losurl+url,23,'','tvshow','')
                        if EnableMeta == 'false':
                               addDir(name,losurl+url,23,'',None,'')
                               
#Routine to search for Actors
def ACTORSEARCH(url):
        keyb = xbmc.Keyboard('', 'Search for Actors at losmovies.es')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                print encode
                encode = encode.replace('%20', '+')
                print encode
                encode = encode.replace('+', ' ')
                print encode
                data = net.http_POST(url,{'q' : encode, 'searchType' : 'actors'}).content
                print data
                match=re.compile('<div class="showRow showRowImage showRowImage"><a href="(.+?)" ><img src="(.+?)" alt=".+?" title=".+?"/></a></div>.+?<h4 class="showRow showRowName showRowText">(.+?)</h4>',re.DOTALL).findall(data)
                for url,iconimage,name in match:
                        addDir(name,losurl+url,5,iconimage,None,'')

#Routine to search for Directors
def DIRSEARCH(url):
        keyb = xbmc.Keyboard('', 'Search for Directors at losmovies.es')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                print encode
                encode = encode.replace('%20', '+')
                print encode
                encode = encode.replace('+', ' ')
                print encode
                data = net.http_POST(url,{'q' : encode, 'searchType' : 'directors'}).content
                print data
                match=re.compile('<div class="showRow showRowImage showRowImage"><a href="(.+?)" ><img src="(.+?)" alt=".+?" title=".+?"/></a></div>.+?<h4 class="showRow showRowName showRowText">(.+?)</h4>',re.DOTALL).findall(data)
                for url,iconimage,name in match:
                        addDir(name,losurl+url,5,iconimage,None,'')
                        
#regex for Featured Movies
def FEATURED(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<li><a href="(.+?)"><img src=".+?" alt="(.+?)" width="125" /></a></li>',re.DOTALL).findall(net.http_GET(url).content)
        for url,name in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,losurl+url+'@'+name,6,'','Movie','')
                if EnableMeta == 'false':
                        addDir(name,losurl+url+'@'+name,6,'',None,'')


#regex for Movies            
def INDEX1(url):
        DVD = local.getSetting('Set-DVD')
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<div class="movieQuality movieQuality(.+?)">.+?<div class="showRow showRowImage showRowImage"><a href="(.+?)" ><img src=".+?" alt=".+?" title="Watch (.+?) Online"/></a></div>',re.DOTALL).findall(net.http_GET(url).content)
        nextpage=re.search('<span class="currentStep">.+?</span><a href="(.+?)"',(net.http_GET(url).content))
        for quality,url,name in match:
                name = silent.CLEAN(name)
                quality = quality.replace('Q3D','3D')
                if EnableMeta == 'true':
                        addDir(name,losurl+url+'@'+name,6,'','Movie',quality)
                        """
                        if DVD == 'true':
                                geturl = losurl+url
                                quality = QUALITY(geturl)
                                if quality:
                                        addDir(name,losurl+url+'@'+name,6,'','Movie')
                        else:
                                addDir(name,losurl+url+'@'+name,6,'','Movie')
                        """
                if EnableMeta == 'false':
                        addDir(name,losurl+url+'@'+name,6,'',None,'')
                        """
                        if DVD == 'true':
                                geturl = losurl+url
                                quality = QUALITY(geturl)
                                if quality:
                                        addDir(name,losurl+url+'@'+name,6,'',None,'')
                        else:
                                        addDir(name,losurl+url+'@'+name,6,'',None,'')
                        """
        if nextpage:
                url = nextpage.group(1)
                url = url.replace('amp;','')
                addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',losurl+url,5,'',None,'')

#regex for Tv-Shows
def INDEX2(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<div class="showRow showRowImage showRowImage"><a href="(.+?)" ><img src=".+?" alt=".+?" title="Watch (.+?) Online"/></a>',re.DOTALL).findall(net.http_GET(url).content)
        nextpage=re.search('<span class="currentStep">.+?</span><a href="(.+?)"',(net.http_GET(url).content))
        for url,name in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,losurl+url,23,'','tvshow','')
                if EnableMeta == 'false':
                        addDir(name,losurl+url,23,'',None,'')
        if nextpage:
                url = nextpage.group(1)
                addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',losurl+url,17,'',None,'')

#regex to find seasons
def SEASONS(url,name):
        match=re.compile('<li><a href="#tabs-.+?">(.+?)</a></li>').findall(net.http_GET(url).content)
        for season in match:
                addDir(season,url+'@'+name,24,'','season','')

#regex to find episodes
def EPISODES(url,name):
        season = name
        title = url.split('@')[1]
        url = url.split('@')[0]
        data=re.compile('<div class="season" id=".+?">(.+?)<div class="adsPlaceHolder adsPlaceHolderComment">',re.DOTALL).findall(net.http_GET(url).content)
        pattern = '<h3>Watch Online: (.+?)</h3>'#Rosemary&#39;s Baby Season 1 Serie 1
        match = re.findall(pattern,str(data))
        for episode in match:
                if name in episode:
                        episode = episode.replace('&#39;', "'")
                        episode = episode.replace('Serie', 'Episode')
                        episode = episode.replace(title, '')
                        episode = episode.replace(name, '')
                        episode = episode.strip()
                        addDir(episode,url+'@'+title+'@'+season,25,'','episode','')

#regex to find episode links
def EPISODELINKS(url,name):
        season = url.split('@')[2]
        print season
        title = url.split('@')[1]
        print title
        url = url.split('@')[0]
        print url
        find=re.compile('<h3>(.+?)</h3>(.+?)</table>',re.DOTALL).findall(net.http_GET(url).content)
        print name
        for episodes,data in find:
                if season in episodes:
                        episodes = episodes.replace('&#39;', "'")
                        episodes = episodes.replace('Serie', 'Episode')
                        name = name.replace(season, '')
                        name = name.replace(title, '')
                        name = name.strip()
                        print name
                        if name in episodes:
                                print episodes
                                pattern = 'class="serverLink .+?" id=".+?".+?title=".+?"> (.+?)\\n</span>.+?<td class=".+?">(.+?)</td>.+?<td class="linkHidden linkHiddenUrl" data-width=".+?" data-height=".+?">(.+?)</td>'
                                match = re.findall(pattern,str(data),re.DOTALL)
                                for host,quality,url in match:
                                        nono = ['HDstream']
                                        url = url.replace(' ', '')
                                        url = url.replace('amp;', '')
                                        url = url.replace('embed-', '')
                                        url = url.replace('-700x460', '')
                                        specialhost = ['iShared','VK']
                                        if host not in nono:
                                                if host not in specialhost:
                                                        url = url.replace('/embed/','/file/')#switch putlocker & sockshare embed to file
                                                        addDir("%s : %s" %(host,quality),url+'@'+title,7,'',None,'')
                                                else:
                                                        addDir("%s : %s" %(host,quality),url+'@'+title,8,'',None,'')
                
#regex for Hoster links
def VIDEOLINKS(url):
        name2 = url.split('@')[1]
        url = url.split('@')[0]
        match=re.compile('class="serverLink .+?" id=".+?".+?title=".+?"> (.+?)\\n</span>.+?<td class=".+?">(.+?)</td>.+?<td class="linkHidden linkHiddenUrl" data-width=".+?" data-height=".+?">(.+?)</td>',re.DOTALL).findall(net.http_GET(url).content)
        for name,quality,url in match:
                nono = ['HDstream','VidSpot']
                url = url.replace(' ', '')
                url = url.replace('amp;', '')
                url = url.replace('embed-', '')
                url = url.replace('-700x460', '')
                specialhost = ['iShared','VK','ExaShare']
                if name not in nono:
                        if name not in specialhost:
                                url = url.replace('/embed/','/file/')#switch putlocker & sockshare embed to file
                                addDir("%s : %s" %(name,quality),url+'@'+name2,7,'',None,'')
                        else:
                                addDir("%s : %s" %(name,quality),url+'@'+name2,8,'',None,'')

#regex to find quality of links before displaying titles
def QUALITY(url):
        match=re.compile('class="serverLink .+?" id=".+?".+?title=".+?"> (.+?)\\n</span></td>.+?</td>.+?<td>(.+?)</td>.+?<td class="linkHidden linkHiddenUrl" data-width=".+?" data-height=".+?">(.+?)</td>.+?<td class="linkHidden linkHiddenVideoBlock">',re.DOTALL).findall(net.http_GET(url).content)
        for name,quality,url in match:
                nono = ['HDstream','VidSpot']
                url = url.replace(' ', '')
                url = url.replace('amp;', '')
                if name not in nono:
                        preffered = ['CAM','TS']
                        if quality not in preffered:
                                return quality
                                
#Routine to resolve host not in metahandlers (VK, iShared, ExaShare)
def SPECIALHOST(url,name):
        print name
        name2 = url.split('@')[1]
        print name2
        url = url.split('@')[0]
        #Get VK final links with quality
        if 'VK' in name:
                print url
                #fix oid= reversed by javascript
                #url = re.sub('oid=(.+?)&', lambda match: "oid=" + match.group(1)[::-1] + "&",url)
                print url
                match720=re.search('url720=(.+?)&amp;',(net.http_GET(url).content))
                match480=re.search('url480=(.+?)&amp;',(net.http_GET(url).content))
                match360=re.search('url360=(.+?)&amp;',(net.http_GET(url).content))
                match260=re.search('url260=(.+?)&amp;',(net.http_GET(url).content))
                if match720:
                        url = match720.group(1)
                        url = url.replace('amp;', '')
                        addLink('VK Quality : 720',url+'@'+name2,'')
                if match480:
                        url = match480.group(1)
                        url = url.replace('amp;', '')
                        addLink('VK Quality : 480',url+'@'+name2,'')
                if match360:
                        url = match360.group(1)
                        url = url.replace('amp;', '')
                        addLink('VK Quality : 360',url+'@'+name2,'')
                if match260:
                        url = match260.group(1)
                        url = url.replace('amp;', '')
                        addLink('VK Quality : 260',url+'@'+name2,'')
                
        #Get iShared final link
        if 'iShared' in name:
                match=re.compile('path:"(.+?)"').findall(net.http_GET(url).content)
                for url in match:
                        addLink(name2,url+'@'+name2,'')

        #Get ExaShare final link
        if 'ExaShare' in name:
                match=re.compile('file: "(.+?)"').findall(net.http_GET(url).content)
                for url in match:
                        addLink(name2,url+'@'+name2,'')

#regex for actor list per movie            
def STARRING(url):
        print url
        name2 = url.split('@')[1]
        url = url.split('@')[0]
        print url
        find = re.compile('<div class="showValue showValueActors">(.+?)</div></div>').findall(net.http_GET(url).content)
        for data in find:
                data = silent.CLEAN(data)
                pattern = '<a href="(.+?)">(.+?)</a>'
                match = re.findall(pattern,str(data),re.DOTALL)
                for url,name in match:
                        addDir(name,losurl+url,5,'',None,'')

#regex for director list per movie            
def DIRECTOR(url):
        print url
        name2 = url.split('@')[1]
        url = url.split('@')[0]
        print url
        find = re.compile('<div class="showLabel showLabelDirectors">(.+?)</div></div>').findall(net.http_GET(url).content)
        for data in find:
                data = silent.CLEAN(data)
                pattern = '<a href="(.+?)">(.+?)</a>'
                match = re.findall(pattern,str(data),re.DOTALL)
                for url,name in match:
                        addDir(name,losurl+url,5,'',None,'')

#Pass url to urlresolver
def STREAM(url):
        EnableMeta = local.getSetting('Enable-Meta')
        name2 = url.split('@')[1]
        print name2
        url = url.split('@')[0]
        print url
        if EnableMeta == 'true':
                infoLabels = silent.GRABMETA(name2,url,'Movies')
                try: img = infoLabels['cover_url']
                except: img= iconimage
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
        print name2
        print streamlink
        addLink(name2,streamlink+'@'+name2,img)

def AUTOSTART(url):
        path = xbmc.translatePath(os.path.join('special://home/userdata',''))
        advance=os.path.join(path, 'autoexec.py')
        dialog = xbmcgui.Dialog()
        if dialog.yesno("LosMovies","" , "Auto Start The LosMovies Addon",'','Disable','Enable'):
                try:
                        os.remove(advance)
                except:
                        pass
                a = open(advance,"w") 
                a.write("import xbmc\nxbmc.executebuiltin('XBMC.RunAddon(plugin.video.losmovies)')\n")
                a.close()
                dialog = xbmcgui.Dialog()
                dialog.ok("LosMovies", "Auto Start For LosMovies Has Been Enabled", 'Please Reboot XBMC')
        else:
                try:
                        os.remove(advance)
                        dialog = xbmcgui.Dialog()
                        dialog.ok("LosMovies", "Auto Start For LosMovies Has Been Disabled", 'Please Reboot XBMC')
                except:
                        dialog = xbmcgui.Dialog()
                        dialog.ok("LosMovies", "Auto Start has not been enabled yet")
                        pass

def AUTOSTARTADD(url,name):
        path = xbmc.translatePath(os.path.join('special://home/userdata',''))
        advance=os.path.join(path, 'autoexec.py')
        try:
                os.remove(advance)
        except:
                pass
        a = open(advance,"w") 
        a.write("import xbmc\nxbmc.executebuiltin('XBMC.RunAddon(%s)')\n" % url)
        a.close()
        dialog = xbmcgui.Dialog()
        dialog.ok("LosMovies", "Auto Start For * %s * Has Been Enabled" % name, 'Please Reboot XBMC')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        name2 = url.split('@')[1]
        print name2
        url = url.split('@')[0]
        print url
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name2 } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok
        """
        #liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        #liz.setInfo('video',infoLabels={ "Title": name2 })
        try:
                xbmc.sleep(2000)
                #xbmc.Player ().play(url, liz, False)
                xbmc.Player(xbmc.PLAYER_CORE_AUTO).play(url)
        except:
                pass
        """

def addDir(name,url,mode,iconimage,types,quality):
        EnableFanArt = local.getSetting('Enable-Fanart')
        ok=True
        type = types
        fimg = addon.get_fanart()
        if type != None:
                infoLabels = silent.GRABMETA(name,url,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        if EnableFanArt == 'true':
                try:    fimg = infoLabels['backdrop_url']
                except: fimg = addon.get_fanart()
        #####get img for actor list####
        if 'actor' in url:
                try: img = re.compile('<div class="showRow showRowImage showRowImage"><img src="(.+?)" alt=".+?" title=".+?"/></div>').findall(net.http_GET(url).content)[0]
                except: img= iconimage
        ###############################
        #####get img for director list####
        if 'director' in url:
                try: img = re.compile('<div class="showRow showRowImage showRowImage"><img src="(.+?)" alt=".+?" title=".+?"/></div>').findall(net.http_GET(url).content)[0]
                except: img= iconimage
        ###############################
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        if quality:
                liz=xbmcgui.ListItem(name+'  :  '+quality, iconImage="DefaultFolder.png", thumbnailImage=img)
        else:
                liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        liz.setProperty( "Fanart_Image", fimg )

        contextMenuItems = []
        #contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        if mode == 6 or mode == 23:
                contextMenuItems = []
                contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
                contextMenuItems.append(('Add to Favorites', 'XBMC.RunPlugin(%s?mode=27&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
                contextMenuItems.append(('Starring', 'XBMC.Container.Update(%s?mode=32&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
                contextMenuItems.append(('Director', 'XBMC.Container.Update(%s?mode=33&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
                liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        if mode == 35 or mode == 36 or mode == 37:
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addFAVDir(name,url,types):
        EnableFanArt = local.getSetting('Enable-Fanart')
        if 'Movie' in types:
                mode = 6
        if 'tvshow' in types:
                mode = 23
        iconimage = ''
        ok=True
        type = types
        fimg = addon.get_fanart()
        if type != None:
                infoLabels = silent.GRABMETA(name,url,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img = iconimage
        if EnableFanArt == 'true':
                try:    fimg = infoLabels['backdrop_url']
                except: fimg = addon.get_fanart()
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        liz.setProperty( "Fanart_Image", fimg )
        contextMenuItems = []
        contextMenuItems.append(('Remove from Favorites', 'XBMC.RunPlugin(%s?mode=28&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
    
params=get_params()
url=None
name=None
mode=None
types=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        types=urllib.unquote_plus(params["types"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
        print ""
        URLCHECK()
        
elif mode==1:
        MOVIES()

elif mode==2:
        MOVIESAZ()

elif mode==3:
        MOVIESGEN()

elif mode==4:
        TVSHOWS()

elif mode==5:
        print ""+url
        INDEX1(url)

elif mode==6:
        print ""+url
        VIDEOLINKS(url)

elif mode==7:
        print ""+url
        STREAM(url)

elif mode==8:
        print ""+url
        SPECIALHOST(url,name)

elif mode==9:
        print ""+url
        MOVIEGEN(url)

elif mode==10:
        print ""+url
        MOVIEAZ(url)

elif mode==11:
        print ""+url
        ACTORS(url)

elif mode==12:
        print ""+url
        COUNTRIES(url)

elif mode==13:
        ACTORSDIR()

elif mode==14:
        DIRECTORDIR()

elif mode==15:
        print ""+url
        SEARCH(url)

elif mode==16:
        print ""+url
        ACTORSEARCH(url)

elif mode==17:
        print ""+url
        INDEX2(url)
        
elif mode==18:
        MOVIES()

elif mode==19:
        TVSHOWS()
        
elif mode==20:
        print ""+url
        TVGEN(url)

elif mode==21:
        print ""+url
        COUNTRIESTV(url)

elif mode==22:
        print ""+url
        SEARCHTV(url)

elif mode==23:
        print ""+url
        SEASONS(url,name)

elif mode==24:
        print ""+url
        EPISODES(url,name)

elif mode==25:
        print ""+url
        EPISODELINKS(url,name)

elif mode==26:
        print ""+url
        GETMYFAVS()

elif mode==27:
        print ""+url
        silent.addFavorite(name,url,types)

elif mode==28:
        print ""+url
        silent.removeFavorite(name,url,types)

elif mode==29:
        print ""+url
        GETMYFAVS()

elif mode==30:
        print ""+url
        COLLECTIONS(url)

elif mode==31:
        print ""+url
        TVAZ(url)

elif mode==32:
        print ""+url
        STARRING(url)

elif mode==33:
        print ""+url
        DIRECTOR(url)

elif mode==34:
        SETTINGS()

elif mode==35:
        addon.addon.openSettings()

elif mode==36:
        urlresolver.display_settings()

elif mode==37:
        AUTOSTART(url)

elif mode==38:
        DIRSEARCH(url)

elif mode==39:
        FEATURED(url)
                                        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
