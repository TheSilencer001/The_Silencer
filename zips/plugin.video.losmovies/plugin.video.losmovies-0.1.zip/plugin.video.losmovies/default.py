import urllib,urllib2,cookielib,base64,re,xbmcplugin,xbmcgui,urlresolver,xbmc,xbmcplugin,xbmcgui,xbmcaddon,os,time,json,socket
from metahandler import metahandlers
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net


#losmovies.com - by The_Silencer 2013 v0.1


grab = metahandlers.MetaData(preparezip = False)
addon_id = 'plugin.video.losmovies'
local = xbmcaddon.Addon(id=addon_id)
lospath = local.getAddonInfo('path')
addon = Addon(addon_id)
datapath = addon.get_profile()
cookie_path = os.path.join(datapath)
art = lospath+'/art'
cookiejar = os.path.join(cookie_path,'losmovies.lwp')
net = Net()


#Losmovies.com login routine
def LOGIN():
        los_account = local.getSetting('los-account')
        hide_message = local.getSetting('hide-successful-login-messages')
        if los_account == 'true':
                loginurl = 'http://losmovies.com/login'
                login = local.getSetting('los-username')
                password = local.getSetting('los-password')
                
                token = GRABTOKEN('http://losmovies.com/login')
                data = net.http_POST(url,{'utf8':'e29c93','authenticity_token':token,'user_session[login]':login,'user_session[password]':password,'commit':'Login'}).content
                success=re.compile('<a href="/accounts/edit/4401">(.+?)</a>.+?<a href="/logout">(.+?)</a>',re.DOTALL).findall(data)
                if success:
                        net.save_cookies(cookiejar)
                        if hide_message == 'false':
                                print 'Losmovies Account: login successful'
                                Notify('small','Losmovies', 'Account login successful.',5000)
                if not success:
                        print 'Losmovies Account: login failed'
                        Notify('big','Losmovies','Login failed: check your username and password', '')

def GRABTOKEN(url):
        content = net.http_GET(url).content
        match=re.search('<input name="authenticity_token" value="(.+?)"', content)
        return match

#Notifications
def Notify(typeq,title,message,times, line2='', line3=''):
     if typeq == 'small':
            smallicon= addon.get_icon()
            xbmc.executebuiltin("XBMC.Notification("+title+","+message+","''","+smallicon+")")
     elif typeq == 'big':
            dialog = xbmcgui.Dialog()
            dialog.ok(' '+title+' ', ' '+message+' ', line2, line3)
     else:
            dialog = xbmcgui.Dialog()
            dialog.ok(' '+title+' ', ' '+message+' ')
            
#Metahandler
def GRABMETA(name,types,year):
        type = types
        EnableMeta = local.getSetting('Enable-Meta')
        if EnableMeta == 'true':
                if 'Movie' in type:
                        meta = grab.get_meta('movie',name,year,None,None,overlay=6)
                        infoLabels = {'rating': meta['rating'],'duration': meta['duration'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],
                          'plot': meta['plot'],'title': meta['title'],'writer': meta['writer'],'cover_url': meta['cover_url'],
                          'director': meta['director'],'cast': meta['cast'],'backdrop_url': meta['backdrop_url'],'tmdb_id': meta['tmdb_id'],'year': meta['year']}
                        return infoLabels
                
#Main menu
def CATEGORIES():
        #LOGIN()
        addDir('New Releases','http://losmovies.com/watch-new-release-movies',5,'',None,'')
        addDir('Latest','http://losmovies.com',5,'',None,'')
        addDir('Most Popular','http://losmovies.com',5,'',None,'')
        addDir('A-Z','http://losmovies.com',10,'',None,'')
        addDir('Genres','http://losmovies.com/movie-genres',9,'',None,'')
        addDir('Actors','http://losmovies.com/actors',13,'',None,'')
        addDir('Directors','http://losmovies.com/directors',14,'',None,'')
        addDir('Countries','http://losmovies.com/countries',12,'',None,'')
        addDir('Search','http://losmovies.com/msearch',15,'',None,'')

def DIRECTORDIR():
        addDir('A-Z','http://losmovies.com/directors',10,'',None,'')
        addDir('Search','http://losmovies.com/movie-genres',9,'',None,'')

def ACTORSDIR():
        addDir('A-Z','http://losmovies.com/actors',10,'',None,'')
        addDir('Search','http://losmovies.com/movie-genres',9,'',None,'')

def COUNTRIES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<div class="countriesImage"><a href=".+?"><img alt=".+?" src="(.+?)" /></a>\n          </div>\n          <div class="countryShortTitle">(.+?)</div>\n          <a href="(.+?)" class="countryShortMovies btn countryShortMoviesGrad btn-block">Movies</a>',re.DOTALL).findall(link)
        for iconimage,name,url in match:
                        addDir(name,'http://losmovies.com/'+url,5,iconimage,None,'')

def ACTORS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)"><img alt=".+?" src="(.+?)" title=".+?" /></a>\n          <h4>(.+?)</h4>',re.DOTALL).findall(link)
        nextpage=re.compile('<a href="(.+?)" class="next_page" rel="next">Forward</a></div>').findall(link)
        for url,iconimage,name in match:
                        addDir(name,'http://losmovies.com/'+url,5,iconimage,None,'')
        for url in nextpage:
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://losmovies.com/'+url,11,'',None,'')
        

def MOVIEAZ(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)" class="letterFilter ">(.+?)</a>').findall(link)
        for url,name in match:
                        if 'actors' in url:
                                nono = ['0', '1', '2', '3', '4', '6', '7', '8', '9']
                                if name not in nono:
                                        addDir(name,'http://losmovies.com/'+url,11,'',None,'')
                        if 'directors' in url:
                                nono = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
                                if name not in nono:
                                        addDir(name,'http://losmovies.com/'+url,11,'',None,'')
                        if 'movie' in url:
                                addDir(name,'http://losmovies.com/'+url,5,'',None,'')

def MOVIEGEN(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<div class="categoryShortTitle">(.+?)</div>.+?<a href="(.+?)" class="categoryShortMovies btn categoryShortMoviesGrad btn-block">Movies</a>',re.DOTALL).findall(link)
        for name,url in match:
                        addDir(name,'http://losmovies.com/'+url,5,'',None,'')
        
def SEARCH(url):
        keyb = xbmc.Keyboard('', 'Search losmovies.com')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace(' ', '+')
                data = net.http_POST(url,{'search' : encode}).content
                match=re.compile('<a href="(.+?)" title="Watch (.+?) Online">',re.DOTALL).findall(data)
                for url,name in match:
                       addDir(name,'http://losmovies.com'+url,6,'','Movie','')
                       
                
def INDEX1(url):
        EnableMeta = local.getSetting('Enable-Meta')
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)" title="Watch (.+?) Online">').findall(link)
        nextpage=re.compile('<a href="(.+?)"class="next_page" rel="next">Forward</a>').findall(link)#<a href="(.+?)" class="next_page" rel="next">Forward</a></div>
        for url,name in match:
                if EnableMeta == 'true':
                        addDir(name,'http://losmovies.com/'+url,6,'','Movie','')
                if EnableMeta == 'false':
                        addDir(name,'http://losmovies.com/'+url,6,'',None,'')
        for url,name in nextpage:
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B] '+url,'http://losmovies.com/'+url,5,'',None,'')
                        
def VIDEOLINKS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<span class=".+?" id=".+?" title=".+?">(.+?)</span></td>\n          <td>.+?<td class="linkTdQuality">(.+?)</td>.+?<td class="linkHidden linkHiddenUrl">\n(.+?)\n.+?</td>',re.DOTALL).findall(link)
        for name,quality,url in match:
                nono = ['HDstream', 'VK']
                url = url.replace(' ', '')
                url = url.replace('amp;', '')
                specialhost = ['iShared']#['VK', 'iShared']
                if name not in nono:
                        if name not in specialhost:
                                addDir("%s : %s" %(name,quality),url,7,'',None,'')
                        else:
                                addDir("%s : %s" %(name,quality),url,8,'',None,'')
                                

#http://vk.com/video_ext.php?oid=104773198&id=165385445&hash=94e914c35e3b9fcf&hd=1
#'http://vk.com/video_ext.php?oid=-35916108&id=163981813&hash=2af35b15071fcdac&sd'
                                
#Resolve host not in metahandlers (VK, iShared)
def SPECIALHOST(url,name):
        #Get VK final link
        if 'VK' in name:
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('url360=(.+?)&amp;').findall(link)
                match2=re.compile('url240=(.+?)&amp;').findall(link)
                for url in match:
                        #name = url
                        #addDir(name,url,8,'',None,'')
                        addLink('Play for high bandwidth',url,'')
                for url in match2:
                        addLink('Play for low bandwidth',url,'')
        #Get iShared final link
        if 'iShared' in name:
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('file:"(.+?)", label: ".+?", type:".+?"').findall(link)
                for url in match:
                        addLink('Play',url,'')
                        
                        
def STREAM(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
        print streamlink
        addLink(name,streamlink,'')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok


def addDir(name,url,mode,iconimage,types,year):
        ok=True
        type = types
        if type != None:
                infoLabels = GRABMETA(name,types,year)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels) 
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
        
elif mode==1:
        MOVIES()

elif mode==2:
        MOVIESAZ()

elif mode==3:
        MOVIESGEN()

elif mode==4:
        TVSHOWS()

elif mode==5:
        print ""+url
        INDEX1(url)

elif mode==6:
        print ""+url
        VIDEOLINKS(url)

elif mode==7:
        print ""+url
        STREAM(url)

elif mode==8:
        print ""+url
        SPECIALHOST(url,name)

elif mode==9:
        print ""+url
        MOVIEGEN(url)

elif mode==10:
        print ""+url
        MOVIEAZ(url)

elif mode==11:
        print ""+url
        ACTORS(url)

elif mode==12:
        print ""+url
        COUNTRIES(url)

elif mode==13:
        ACTORSDIR()

elif mode==14:
        DIRECTORDIR()

elif mode==15:
        print ""+url
        SEARCH(url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
