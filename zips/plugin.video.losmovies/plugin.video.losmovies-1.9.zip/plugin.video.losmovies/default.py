import urllib,urllib2,re,xbmcplugin,xbmcgui,urlresolver,xbmc,xbmcaddon,os
from metahandler import metahandlers
from addon.common.addon import Addon
from addon.common.net import Net
import silent


#losmovies.com - by The_Silencer 2013 v1.9


grab = metahandlers.MetaData(preparezip = False)
addon_id = 'plugin.video.losmovies'
local = xbmcaddon.Addon(id=addon_id)
lospath = local.getAddonInfo('path')
addon = Addon(addon_id, sys.argv)
datapath = addon.get_profile()
art = lospath+'/art'
net = Net()
metaget = metahandlers.MetaData()


                
#Main menu
def CATEGORIES():
        addDir('Movies','http://losmovies.com/',18,'',None)
        addDir('TV Shows','http://losmovies.com/',19,'',None)
        addDir('Search','http://losmovies.com/msearch',15,'',None)
        addDir('Favorites','http://losmovies.com/',26,'',None)

def MOVIES():
        addDir('New Releases','http://losmovies.com/watch-new-release-movies',5,'',None)
        addDir('Latest','http://losmovies.com/watch-latest-movies',5,'',None)
        addDir('Most Popular','http://losmovies.com',5,'',None)
        addDir('HD','http://losmovies.com/watch-movies-in-hd',5,'',None)
        addDir('Collections','http://losmovies.com/movie-collection',30,'',None)
        addDir('A-Z','http://losmovies.com',10,'',None)
        addDir('Genres','http://losmovies.com/movie-genres',9,'',None)
        addDir('Actors','http://losmovies.com/actors',13,'',None)
        addDir('Directors','http://losmovies.com/directors',14,'',None)
        addDir('Countries','http://losmovies.com/countries',12,'',None)
        addDir('Search','http://losmovies.com/msearch',15,'',None)

def TVSHOWS():
        addDir('New Releases','http://losmovies.com/watch-new-release-tv-shows',17,'',None)
        addDir('Latest','http://losmovies.com/watch-latest-tv-shows',17,'',None)
        addDir('Most Popular','http://losmovies.com/watch-popular-tv-shows',17,'',None)
        addDir('HD','http://losmovies.com/watch-tv-shows-in-hd',17,'',None)
        addDir('A-Z','http://losmovies.com/watch-popular-tv-shows',31,'',None)
        addDir('Genres','http://losmovies.com/movie-genres',20,'',None)
        addDir('Actors','http://losmovies.com/actors',13,'',None)
        addDir('Directors','http://losmovies.com/directors',14,'',None)
        addDir('Countries','http://losmovies.com/countries',21,'',None)
        addDir('Search','http://losmovies.com/msearch',22,'',None)

def DIRECTORDIR():
        addDir('A-Z','http://losmovies.com/directors',10,'',None)
        addDir('Search','http://losmovies.com/dsearch',16,'',None)

def ACTORSDIR():
        addDir('A-Z','http://losmovies.com/actors',10,'',None)
        addDir('Search','http://losmovies.com/asearch',16,'',None)

#Return Favorites List *temp need to fix in silent*
def GETMYFAVS():
        MYFAVS = silent.getFavorites()
        print MYFAVS
        for name,url,types in MYFAVS:
                addFAVDir(name,url,types)

#regex for countires movies
def COUNTRIES(url):
        match=re.compile('<div class="countriesImage"><a href=".+?"><img alt=".+?" src="(.+?)" /></a>\n          </div>\n          <div class="countryShortTitle">(.+?)</div>\n          <a href="(.+?)" class="countryShortMovies btn countryShortMoviesGrad btn-block">Movies</a>',re.DOTALL).findall(net.http_GET(url).content)
        for iconimage,name,url in match:
                        addDir(name,'http://losmovies.com/'+url,5,iconimage,None)

#regex for Movie Collections
def COLLECTIONS(url):
        match=re.compile('<a href="(.+?)" class="rubricButton"><img alt="(.+?)" src="(.+?)" /></a>').findall(net.http_GET(url).content)
        for url,name,iconimage in match:
                        addDir(name,'http://losmovies.com/'+url,5,iconimage,None)

#regex for countires tv shows
def COUNTRIESTV(url):
        match=re.compile('<div class="countriesImage"><a href=".+?"><img alt=".+?" src="(.+?)" /></a>\n          </div>\n          <div class="countryShortTitle">(.+?)</div>\n          <a href=".+?" class="countryShortMovies btn countryShortMoviesGrad btn-block">Movies</a>.+?<a href="(.+?)" class="countryShortTvShows btn countryShortTvShowsGrad btn-block">TV Shows</a>',re.DOTALL).findall(net.http_GET(url).content)
        for iconimage,name,url in match:
                        addDir(name,'http://losmovies.com/'+url,17,iconimage,None)

#regex for actors
def ACTORS(url):
        match=re.compile('<a href="(.+?)"><img alt=".+?" src="(.+?)" title=".+?" /></a>\n          <h4>(.+?)</h4>',re.DOTALL).findall(net.http_GET(url).content)
        nextpage=re.search('<span class="current">.+?</span> <a href="(.+?)"',(net.http_GET(url).content))
        for url,iconimage,name in match:
                        name = silent.CLEAN(name)
                        addDir(name.encode('UTF-8','ignore'),'http://losmovies.com/'+url,5,iconimage,None)
        if nextpage:
                        url = nextpage.group(1)
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://losmovies.com/'+url,11,'',None)

#regex for Movie A-Z list
def MOVIEAZ(url):
        match=re.compile('<a href="(.+?)" class="letterFilter ">(.+?)</a>').findall(net.http_GET(url).content)
        for url,name in match:
                        if 'actors' in url:
                                nono = ['0', '1', '2', '3', '4', '6', '7', '8', '9']
                                if name not in nono:
                                        addDir(name,'http://losmovies.com/'+url,11,'',None)
                        elif 'directors' in url:
                                nono = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
                                if name not in nono:
                                        addDir(name,'http://losmovies.com/'+url,11,'',None)
                        else:
                                addDir(name,'http://losmovies.com/'+url,5,'',None)

#regex for TV A-Z list
def TVAZ(url):
        match=re.compile('<a href="(.+?)" class="letterFilter ">(.+?)</a>').findall(net.http_GET(url).content)
        for url,name in match:
                        addDir(name,'http://losmovies.com/'+url,17,'',None)

#regex for genres movies  
def MOVIEGEN(url):
        match=re.compile('<div class="categoryShortTitle">(.+?)</div>.+?<a href="(.+?)" class="categoryShortMovies btn categoryShortMoviesGrad btn-block">Movies</a>',re.DOTALL).findall(net.http_GET(url).content)
        for name,url in match:
                        addDir(name,'http://losmovies.com/'+url,5,'',None)

#regex for genres tv shows 
def TVGEN(url):
        match=re.compile('<div class="categoryShortTitle">(.+?)</div>.+?<a href=".+?" class="categoryShortMovies btn categoryShortMoviesGrad btn-block">Movies</a>.+?<a href="(.+?)" class=".+?">TV Shows</a>',re.DOTALL).findall(net.http_GET(url).content)
        for name,url in match:
                        addDir(name,'http://losmovies.com/'+url,17,'',None)

#Routine to search for Movies
def SEARCH(url):
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search Movies from losmovies.com')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace('%20', ' ')
                print encode
                data = net.http_POST(url,{'search' : encode}).content
                match=re.compile('<a href="(.+?)".+?title="Watch (.+?) Online">').findall(data)  
                for url,name in match:
                        name = silent.CLEAN(name)
                        if EnableMeta == 'true':
                               addDir(name,'http://losmovies.com'+url+'@'+name,6,'','Movie')
                        if EnableMeta == 'false':
                               addDir(name,'http://losmovies.com'+url+'@'+name,6,'',None)

#Routine to search for TV Shows
def SEARCHTV(url):
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search TV Shows from losmovies.com')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace('%20', ' ')
                print encode
                data = net.http_POST(url,{'search' : encode}).content
                match=re.compile('<a href="(.+?)".+?title="Watch (.+?) Online">').findall(data)  
                for url,name in match:
                        name = silent.CLEAN(name)
                        if EnableMeta == 'true':
                               addDir(name,'http://losmovies.com'+url+'@'+name,23,'','tvshow')
                        if EnableMeta == 'false':
                               addDir(name,'http://losmovies.com'+url+'@'+name,23,'',None)
                               
#Routine to search for Actors & Directors
def ACTORSEARCH(url):
        keyb = xbmc.Keyboard('', 'Search for Actors at losmovies.com')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace('%20', ' ')
                print encode
                data = net.http_POST(url,{'search' : encode}).content
                match=re.compile('<div class="actorContainer thumbnail">.+?<a href="(.+?)"><img alt="(.+?)" src="(.+?)" /></a>.+?<h4>.+?</h4>',re.DOTALL).findall(data)
                for url,name,iconimage in match:
                        addDir(name,'http://losmovies.com'+url,5,iconimage,None)
                        
#regex for Movies            
def INDEX1(url):
        EnableMeta = local.getSetting('Enable-Meta')
        hd=re.compile('<div class="movieHD">(.+?)</div>\n  <div class="movieInfo">\n    <div class="movieIcon">\n      <div class="inf"></div>\n    </div>\n    <div class="moviePreview" id=".+?"></div>\n  </div>\n  <a href="(.+?)" title="Watch (.+?) Online">').findall(net.http_GET(url).content)
        match=re.compile('<a href="(.+?)" title="Watch (.+?) Online">').findall(net.http_GET(url).content)
        nextpage=re.search('<span class="current">.+?</span> <a href="(.+?)"',(net.http_GET(url).content))
        for url,name in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://losmovies.com/'+url+'@'+name,6,'','Movie')
                if EnableMeta == 'false':
                        addDir(name,'http://losmovies.com/'+url+'@'+name,6,'',None)
        if nextpage:
                url = nextpage.group(1)
                addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://losmovies.com/'+url,5,'',None)

#regex for Tv-Shows
def INDEX2(url):
        EnableMeta = local.getSetting('Enable-Meta')
        hd=re.compile('<div class="movieHD">(.+?)</div>\n  <div class="movieInfo">\n    <div class="movieIcon">\n      <div class="inf"></div>\n    </div>\n    <div class="moviePreview" id=".+?"></div>\n  </div>\n  <a href="(.+?)" title="Watch (.+?) Online">').findall(net.http_GET(url).content)
        match=re.compile('<a href="(.+?)" title="Watch (.+?) Online">').findall(net.http_GET(url).content)
        nextpage=re.search('<span class="current">.+?</span> <a href="(.+?)"',(net.http_GET(url).content))
        for url,name in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://losmovies.com/'+url,23,'','tvshow')
                if EnableMeta == 'false':
                        addDir(name,'http://losmovies.com/'+url,23,'',None)
        if nextpage:
                url = nextpage.group(1)
                addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://losmovies.com/'+url,17,'',None)

#regex to find seasons
def SEASONS(url,name):
        match=re.compile('<li><a href="(.+?)">(.+?)</a></li>').findall(net.http_GET(url).content)
        for tab,season in match:
                tab = tab.replace('#', '')
                addDir(season,url+'@'+name,24,'','season')

#regex to find episodes
def EPISODES(url,name):
        season = name
        title = url.split('@')[1]
        url = url.split('@')[0]
        data=re.compile('<div id="seasons">(.+?)<div class="commentsSection">',re.DOTALL).findall(net.http_GET(url).content)
        pattern = '<h3>Watch Online: (.+?)</h3>'
        match = re.findall(pattern,str(data))
        for episode in match:
                if name in episode:
                        episode = episode.replace(title, '')
                        episode = episode.replace(name, '')
                        episode = episode.strip()
                        addDir(episode,url+'@'+title+'@'+season,25,'','episode')

#regex to find episode links
def EPISODELINKS(url,name):
        season = url.split('@')[2]
        print season
        title = url.split('@')[1]
        print title
        url = url.split('@')[0]
        print url
        find=re.compile('<h3>(.+?)</h3>(.+?)</td>\n          </tr>\n      <tbody>\n    </table>',re.DOTALL).findall(net.http_GET(url).content)
        print name
        for episodes,data in find:
                if season in episodes:
                        name = name.replace(season, '')
                        name = name.replace(title, '')
                        name = name.strip()
                        print name
                        if name in episodes:
                                print episodes
                                pattern = '<span class=".+?" id=".+?" title="Watch .+? Online in (.+?)">.+?</span></td>\n          <td>.+?<td class="linkTdQuality">(.+?)</td>.+?<td class="linkHidden linkHiddenUrl">\n(.+?)\n.+?</td>'
                                match = re.findall(pattern,str(data),re.DOTALL)
                                for host,quality,url in match:
                                        nono = ['HDstream']
                                        url = url.replace(' ', '')
                                        url = url.replace('amp;', '')
                                        specialhost = ['iShared','VK','Allmyvideos']
                                        if host not in nono:
                                                if host not in specialhost:
                                                        url = url.replace('/embed/','/file/')#switch putlocker & sockshare embed to file
                                                        addDir("%s : %s" %(host,quality),url+'@'+title,7,'',None)
                                                else:
                                                        addDir("%s : %s" %(host,quality),url+'@'+title,8,'',None)
                
#regex for Hoster links
def VIDEOLINKS(url):
        name2 = url.split('@')[1]
        url = url.split('@')[0]
        match=re.compile('<span class=".+?" id=".+?" title="Watch .+? Online in (.+?)">.+?</span></td>\n          <td>.+?<td class="linkTdQuality">(.+?)</td>.+?<td class="linkHidden linkHiddenUrl">\n(.+?)\n.+?</td>',re.DOTALL).findall(net.http_GET(url).content)
        for name,quality,url in match:
                nono = ['HDstream','VidSpot']
                url = url.replace(' ', '')
                url = url.replace('amp;', '')
                specialhost = ['iShared','VK','Allmyvideos']
                if name not in nono:
                        if name not in specialhost:
                                url = url.replace('/embed/','/file/')#switch putlocker & sockshare embed to file
                                addDir("%s : %s" %(name,quality),url+'@'+name2,7,'',None)
                        else:
                                addDir("%s : %s" %(name,quality),url+'@'+name2,8,'',None)
                                
#Routine to resolve host not in metahandlers (VK, iShared, ALLmyvideos)
def SPECIALHOST(url,name):
        print name
        name2 = url.split('@')[1]
        print name2
        url = url.split('@')[0]
        #Get VK final links with quality
        if 'VK' in name:
                #fix oid= reversed by javascript
                url = re.sub('oid=(.+?)&', lambda match: "oid=" + match.group(1)[::-1] + "&",url)
                print url
                match720=re.search('url720=(.+?)&amp;',(net.http_GET(url).content))
                match480=re.search('url480=(.+?)&amp;',(net.http_GET(url).content))
                match360=re.search('url360=(.+?)&amp;',(net.http_GET(url).content))
                match260=re.search('url260=(.+?)&amp;',(net.http_GET(url).content))
                match240=re.search('url240=(.+?)&amp;',(net.http_GET(url).content))
                if match720:
                        url = match720.group(1)
                        url = url.replace('amp;', '')
                        addLink('VK Quality : 720',url+'@'+name2,'')
                if match480:
                        url = match480.group(1)
                        url = url.replace('amp;', '')
                        addLink('VK Quality : 480',url+'@'+name2,'')
                if match360:
                        url = match360.group(1)
                        url = url.replace('amp;', '')
                        addLink('VK Quality : 360',url+'@'+name2,'')
                if match260:
                        url = match260.group(1)
                        url = url.replace('amp;', '')
                        addLink('VK Quality : 260',url+'@'+name2,'')
                if match240:
                        url = match240.group(1)
                        url = url.replace('amp;', '')
                        addLink('VK Quality : 240',url+'@'+name2,'')

                
        #Get iShared final link
        if 'iShared' in name:
                match=re.compile('path:"(.+?)"').findall(net.http_GET(url).content)
                for url in match:
                        addLink(name2,url+'@'+name2,'')

        #Get Allmyvideos final link
        if 'Allmyvideos' in name:
                match=re.compile('{\n               "file" : "(.+?)".+?"label" : "(.+?)"',re.DOTALL).findall(net.http_GET(url).content)
                for url,quality in match:
                        addLink('Allmyvideos Quality : '+quality,url+'@'+name2,'')

#regex for actor list per movie            
def STARRING(url):
        match=re.compile('<a href="(.+?)" title=".+?">(.+?),</a>').findall(net.http_GET(url).content)
        for url,name in match:
                name = silent.CLEAN(name)
                addDir(name,'http://losmovies.com/'+url,5,'',None)

#regex for director list per movie            
def DIRECTOR(url):
        match=re.compile('<div>Director</div>\n              </div>\n                  <a href="(.+?)">(.+?)</a>',re.DOTALL).findall(net.http_GET(url).content)
        for url,name in match:
                name = silent.CLEAN(name)
                addDir(name,'http://losmovies.com/'+url,5,'',None)

#Pass url to urlresolver
def STREAM(url):
        EnableMeta = local.getSetting('Enable-Meta')
        name2 = url.split('@')[1]
        print name2
        url = url.split('@')[0]
        print url
        if EnableMeta == 'true':
                infoLabels = silent.GRABMETA(name2,url,'Movies')
                try: img = infoLabels['cover_url']
                except: img= iconimage
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
        print name2
        print streamlink
        addLink(name2,streamlink+'@'+name2,img)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        EnableMeta = local.getSetting('Enable-Meta')
        name2 = url.split('@')[1]
        print name2
        url = url.split('@')[0]
        print url
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name2 } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok

def addDir(name,url,mode,iconimage,types):
        EnableFanArt = local.getSetting('Enable-Fanart')
        ok=True
        type = types
        fimg = addon.get_fanart()
        if type != None:
                infoLabels = silent.GRABMETA(name,url,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        if EnableFanArt == 'true':
                try:    fimg = infoLabels['backdrop_url']
                except: fimg = addon.get_fanart()
        #####get img for actor list####
        if 'actor' in url:
                try: img = re.compile('<div class="imageActor"><img alt=".+?" src="(.+?)" title=".+?" /></div>').findall(net.http_GET(url).content)[0]
                except: img= iconimage
        ###############################
        #####get img for director list####
        if 'director' in url:
                try: img = re.compile('<div class="imageDirector"><img alt=".+?" src="(.+?)" title=".+?" /></div>').findall(net.http_GET(url).content)[0]
                except: img= iconimage
        ###############################
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        liz.setProperty( "Fanart_Image", fimg )

        contextMenuItems = []
        #contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        if mode == 6 or mode == 23:
                contextMenuItems = []
                contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
                contextMenuItems.append(('Add to Favorites', 'XBMC.RunPlugin(%s?mode=27&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
                contextMenuItems.append(('Starring', 'XBMC.Container.Update(%s?mode=32&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
                contextMenuItems.append(('Director', 'XBMC.Container.Update(%s?mode=33&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
                liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addFAVDir(name,url,types):
        EnableFanArt = local.getSetting('Enable-Fanart')
        if 'Movie' in types:
                mode = 6
        if 'tvshow' in types:
                mode = 23
        iconimage = ''
        ok=True
        type = types
        fimg = addon.get_fanart()
        if type != None:
                infoLabels = silent.GRABMETA(name,url,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img = iconimage
        if EnableFanArt == 'true':
                try:    fimg = infoLabels['backdrop_url']
                except: fimg = addon.get_fanart()
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        liz.setProperty( "Fanart_Image", fimg )
        contextMenuItems = []
        contextMenuItems.append(('Remove from Favorites', 'XBMC.RunPlugin(%s?mode=28&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
    
params=get_params()
url=None
name=None
mode=None
types=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        types=urllib.unquote_plus(params["types"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
        
elif mode==1:
        MOVIES()

elif mode==2:
        MOVIESAZ()

elif mode==3:
        MOVIESGEN()

elif mode==4:
        TVSHOWS()

elif mode==5:
        print ""+url
        INDEX1(url)

elif mode==6:
        print ""+url
        VIDEOLINKS(url)

elif mode==7:
        print ""+url
        STREAM(url)

elif mode==8:
        print ""+url
        SPECIALHOST(url,name)

elif mode==9:
        print ""+url
        MOVIEGEN(url)

elif mode==10:
        print ""+url
        MOVIEAZ(url)

elif mode==11:
        print ""+url
        ACTORS(url)

elif mode==12:
        print ""+url
        COUNTRIES(url)

elif mode==13:
        ACTORSDIR()

elif mode==14:
        DIRECTORDIR()

elif mode==15:
        print ""+url
        SEARCH(url)

elif mode==16:
        print ""+url
        ACTORSEARCH(url)

elif mode==17:
        print ""+url
        INDEX2(url)
        
elif mode==18:
        MOVIES()

elif mode==19:
        TVSHOWS()
        
elif mode==20:
        print ""+url
        TVGEN(url)

elif mode==21:
        print ""+url
        COUNTRIESTV(url)

elif mode==22:
        print ""+url
        SEARCHTV(url)

elif mode==23:
        print ""+url
        SEASONS(url,name)

elif mode==24:
        print ""+url
        EPISODES(url,name)

elif mode==25:
        print ""+url
        EPISODELINKS(url,name)

elif mode==26:
        print ""+url
        GETMYFAVS()

elif mode==27:
        print ""+url
        silent.addFavorite(name,url,types)

elif mode==28:
        print ""+url
        silent.removeFavorite(name,url,types)

elif mode==29:
        print ""+url
        GETMYFAVS()

elif mode==30:
        print ""+url
        COLLECTIONS(url)

elif mode==31:
        print ""+url
        TVAZ(url)

elif mode==32:
        print ""+url
        STARRING(url)

elif mode==33:
        print ""+url
        DIRECTOR(url)
                                        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
