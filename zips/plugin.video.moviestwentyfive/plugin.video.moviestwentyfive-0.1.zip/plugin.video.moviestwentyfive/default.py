import urllib,urllib2,re,xbmcplugin,xbmcgui,urlresolver,xbmc,xbmcaddon,os
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net
import silent


#www.movie25.so - by The_Silencer 2013 v0.1
#Thank you umOuch for all the artwork


addon_id = 'plugin.video.moviestwentyfive'
local = xbmcaddon.Addon(id=addon_id)
movie25path = local.getAddonInfo('path')
addon = Addon(addon_id, sys.argv)
datapath = addon.get_profile()
art = movie25path+'/art'
net = Net()


#Main menu
def CATEGORIES():
        addDir('Featured','http://www.movie25.so/',1,os.path.join(art,'featured.png'),None,None)
        addDir('New Releases','http://www.movie25.so/movies/new-releases/',1,os.path.join(art,'newreleases.png'),None,None)
        addDir('Latest Added','http://www.movie25.so/movies/latest-added/',1,os.path.join(art,'latestadded.png'),None,None)
        addDir('Latest HD','http://www.movie25.so/movies/latest-hd-movies/',1,os.path.join(art,'latesthd.png'),None,None)
        addDir('Most Viewed','http://www.movie25.so/movies/most-viewed/',1,os.path.join(art,'mostviewed.png'),None,None)
        addDir('Most Voted','http://www.movie25.so/movies/most-viewed/',1,os.path.join(art,'mostvoted.png'),None,None)
        addDir('A-Z','http://www.movie25.so/',5,os.path.join(art,'a-z.png'),None,None)
        addDir('Genres','http://www.movie25.so/',8,os.path.join(art,'genres.png'),None,None)
        addDir('Year','http://www.movie25.so/',13,os.path.join(art,'year.png'),None,None)
        addDir('Search','http://www.movie25.so/',6,os.path.join(art,'search.png'),None,None)
        addDir('Favorites','http://www.movie25.so/',7,os.path.join(art,'favorites.png'),None,None)

#List of Years
def YEAR():
        addDir('2013','http://www.movie25.so/search.php?year=2013',12,'',None,None)
        addDir('2012','http://www.movie25.so/search.php?year=2012',12,'',None,None)
        addDir('2011','http://www.movie25.so/search.php?year=2011',12,'',None,None)
        addDir('2010','http://www.movie25.so/search.php?year=2010',12,'',None,None)
        addDir('2009','http://www.movie25.so/search.php?year=2009',12,'',None,None)
        addDir('2008','http://www.movie25.so/search.php?year=2008',12,'',None,None)
        addDir('2007','http://www.movie25.so/search.php?year=2007',12,'',None,None)
        addDir('2006','http://www.movie25.so/search.php?year=2006',12,'',None,None)
        addDir('2005','http://www.movie25.so/search.php?year=2005',12,'',None,None)
        addDir('2004','http://www.movie25.so/search.php?year=2004',12,'',None,None)
        addDir('2003','http://www.movie25.so/search.php?year=2003',12,'',None,None)
        addDir('2002','http://www.movie25.so/search.php?year=2002',12,'',None,None)
        addDir('2001','http://www.movie25.so/search.php?year=2001',12,'',None,None)
        addDir('2000','http://www.movie25.so/search.php?year=2000',12,'',None,None)
        addDir('1999','http://www.movie25.so/search.php?year=1999',12,'',None,None)
        addDir('1998','http://www.movie25.so/search.php?year=1998',12,'',None,None)
        addDir('1997','http://www.movie25.so/search.php?year=1997',12,'',None,None)
        addDir('1996','http://www.movie25.so/search.php?year=1996',12,'',None,None)
        addDir('1995','http://www.movie25.so/search.php?year=1995',12,'',None,None)
        addDir('1994','http://www.movie25.so/search.php?year=1994',12,'',None,None)
        addDir('1993','http://www.movie25.so/search.php?year=1993',12,'',None,None)
        addDir('1992','http://www.movie25.so/search.php?year=1992',12,'',None,None)
        addDir('1991','http://www.movie25.so/search.php?year=1991',12,'',None,None)
        addDir('1990','http://www.movie25.so/search.php?year=1990',12,'',None,None)
        addDir('1989','http://www.movie25.so/search.php?year=1989',12,'',None,None)
        addDir('1988','http://www.movie25.so/search.php?year=1988',12,'',None,None)
        addDir('1987','http://www.movie25.so/search.php?year=1987',12,'',None,None)
        addDir('1986','http://www.movie25.so/search.php?year=1986',12,'',None,None)
        addDir('1985','http://www.movie25.so/search.php?year=1985',12,'',None,None)
        addDir('1984','http://www.movie25.so/search.php?year=1984',12,'',None,None)
        addDir('1983','http://www.movie25.so/search.php?year=1983',12,'',None,None)
        addDir('1982','http://www.movie25.so/search.php?year=1982',12,'',None,None)
        addDir('1981','http://www.movie25.so/search.php?year=1981',12,'',None,None)
        addDir('1980','http://www.movie25.so/search.php?year=1980',12,'',None,None)
        addDir('1979','http://www.movie25.so/search.php?year=1979',12,'',None,None)
        addDir('1978','http://www.movie25.so/search.php?year=1978',12,'',None,None)
        addDir('1977','http://www.movie25.so/search.php?year=1977',12,'',None,None)
        addDir('1976','http://www.movie25.so/search.php?year=1976',12,'',None,None)
        addDir('1975','http://www.movie25.so/search.php?year=1975',12,'',None,None)
        addDir('1974','http://www.movie25.so/search.php?year=1974',12,'',None,None)
        addDir('1973','http://www.movie25.so/search.php?year=1973',12,'',None,None)
        addDir('1972','http://www.movie25.so/search.php?year=1972',12,'',None,None)
        addDir('1971','http://www.movie25.so/search.php?year=1971',12,'',None,None)
        addDir('1970','http://www.movie25.so/search.php?year=1970',12,'',None,None)

#Return Favorites List *temp need to fix in silent*
def GETMYFAVS():
        MYFAVS = silent.getFavorites()
        for name,url,year in MYFAVS:
                addFAVDir(name,url,year)

#Search for movies by year selected
def YEARFIND(url):
        EnableMeta = local.getSetting('Enable-Meta')
        pages=re.compile('found&nbsp;&nbsp;&nbsp;&nbsp;(.+?)/(.+?)&nbsp;Page').findall(net.http_GET(url).content)
        match=re.compile('<h1><a href="(.+?)" target="_blank">\n\t\t\t\t\t  (.+?) \(([\d]{4})\)\t\t\t\t\t  </a></h1>').findall(net.http_GET(url).content)
        nextpage=re.compile('<font color=\'#FF3300\'>.+?</font>&nbsp;<a href=\'(.+?)\' >.+?</a>').findall(net.http_GET(url).content)
        for current,last in pages:
                addDir('[B][COLOR yellow]Page  %s  of  %s[/COLOR][/B]'%(current,last),'http://www.movie25.so'+url,2,'',None,None)
        for url,name,year in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://www.movie25.so'+url,2,'','Movie',year)
                if EnableMeta == 'false':
                        addDir(name,'http://www.movie25.so'+url,2,'',None,None)
        if nextpage:
                print nextpage
                url = str(nextpage)
                print url
                url = url.replace('[u\'','')
                url = url.replace(']','')
                url = url.replace('\'','')
                url = '/'+url
                print url
                if EnableMeta == 'true':
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://www.movie25.so'+url,12,'',None,None)
                if EnableMeta == 'false':
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://www.movie25.so'+url,12,'',None,None)
                        
#A-Z list
def AZ(url):
        match2=re.compile('<a href="(.+?)">(.+?)</a>').findall(net.http_GET(url).content)
        match=re.compile('<a href="(.+?)"\ >(.+?)</a>').findall(net.http_GET(url).content)
        for url,name in match2:
                ok = ['0-9']
                if name in ok:
                        addDir(name,'http://www.movie25.so'+url,1,'',None,None)
        for url,name in match:
                ok = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z']
                A = ['A']
                if name in ok:
                        if name in A:
                                url = '/movies/a/'
                        addDir(name,'http://www.movie25.so'+url,1,'',None,None)

#Genres list
def GENRES(url):
        match=re.compile('<li><a href="(.+?)">(.+?)</a></li>').findall(net.http_GET(url).content)
        for url,name in match:
                nono = ['Home', 'New Releases', 'Latest Added', 'Featured Movies', 'Latest HD Movies', 'Most Viewed', 'Most Viewed', 'Most Voted', 'Genres', 'Submit Links']
                if name not in nono:
                        addDir(name,'http://www.movie25.so'+url,1,'',None,None)

#Search for Movies
def SEARCH(url):
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search Movie25')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace('%20', '+')
                print encode
                url = 'http://www.movie25.so/search.php?key='+encode+'&submit='
                print url
                match=re.compile('<h1><a href="(.+?)" target="_blank">\n\t\t\t\t\t  (.+?) \(([\d]{4})\)\t\t\t\t\t  </a></h1>').findall(net.http_GET(url).content)
                for url,name,year in match:
                        name = silent.CLEAN(name)
                        if EnableMeta == 'true':
                               addDir(name,'http://www.movie25.so'+url,2,'','Movie',year)
                        if EnableMeta == 'false':
                               addDir(name,'http://www.movie25.so'+url,2,'',None,None)

def INDEX(url):
        EnableMeta = local.getSetting('Enable-Meta')
        pages=re.compile('found&nbsp;&nbsp;&nbsp;&nbsp;(.+?)/(.+?)&nbsp;Page').findall(net.http_GET(url).content)
        match=re.compile('<div class="movie_pic"><a href="(.+?)"  target="_self">\n\t\t\t\t  \t\t\t\t  <img src=".+?" width="101" height="150" alt="(.+?)\(([\d]{4})\)"',re.DOTALL).findall(net.http_GET(url).content)
        nextpage=re.compile('<font color=\'#FF3300\'>.+?</font>&nbsp;<a href=\'(.+?)\' >.+?</a>').findall(net.http_GET(url).content)
        for current,last in pages:
                addDir('[B][COLOR yellow]Page  %s  of  %s[/COLOR][/B]'%(current,last),'http://www.movie25.so'+url,2,'',None,None)
        for url,name,year in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://www.movie25.so'+url,2,'','Movie',year)
                if EnableMeta == 'false':
                        addDir(name,'http://www.movie25.so'+url,2,'',None,None)

        if nextpage:
                print nextpage
                url = str(nextpage)
                print url
                url = url.replace('[u\'','')
                url = url.replace(']','')
                url = url.replace('\'','')
                print url
                if EnableMeta == 'true':
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://www.movie25.so'+url,1,'',None,None)
                if EnableMeta == 'false':
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://www.movie25.so'+url,1,'',None,None)

#First page with Hosters
def VIDEOLINKS(name,url,year):
        EnableMeta = local.getSetting('Enable-Meta')
        iconimage = ''
        name2 = name
        if EnableMeta == 'true':
                infoLabels = silent.GRABMETA(name2,year)
        try: img = infoLabels['cover_url']
        except: img = iconimage
        match=re.compile('<li class="link_name">\n              (.+?)            </li>\n                        <li class="playing_button"><span><a href="(.+?)"').findall(net.http_GET(url).content)
        List=[]; ListU=[]; c=0
        for name,url in match:
                url = 'http://www.movie25.so'+url+'@'+name2
                c=c+1; List.append(str(c)+'.)  '+name); ListU.append(url)
        dialog=xbmcgui.Dialog()
        rNo=dialog.select('Select A Host', List)
        rName=List[rNo]
        rURL=ListU[rNo]
        VIDEOLINKS2(rName,rURL,year)

#Get the Final Hoster link
def VIDEOLINKS2(name,url,year):
        EnableMeta = local.getSetting('Enable-Meta')
        name2 = url.split('@')[1]
        url = url.split('@')[0]
        iconimage = ''
        if EnableMeta == 'true':
                infoLabels = silent.GRABMETA(name2,year)
        try: img = infoLabels['cover_url']
        except: img = iconimage
        match=re.compile('type="button" onclick="location.href=\'(.+?)\'"  value="Click Here to Play"').findall(net.http_GET(url).content)
        for url in match:
                nono = ['http://www.movie25.so/watch/']
                if url not in nono:
                        STREAM(name,url+'@'+name2,img)

#Pass url to urlresolver
def STREAM(name,url,img):
        download_enabled = local.getSetting('movies25-download')
        name2 = url.split('@')[1]
        url2 = url.split('@')[0]
        print url2
        req = urllib2.Request(url2)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
        print streamlink
        addLink(name2,streamlink,img)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        download_enabled = local.getSetting('movies25-download')
        print url
        ok=True
        try: addon.resolve_url(streamlink)
        except: pass
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo('Video', infoLabels={ "Title": name } )
        ###Download Context Menu
        contextMenuItems = []
        if download_enabled == 'true':
                contextMenuItems = []
                contextMenuItems.append(('Download', 'XBMC.RunPlugin(%s?mode=9&name=%s&url=%s)' % (sys.argv[0], name, urllib.quote_plus(url))))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ########################
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok

def addDir(name,url,mode,iconimage,types,year):
        EnableFanArt = local.getSetting('Enable-Fanart')
        ok=True
        type = types
        fimg = addon.get_fanart()
        if type != None:
                infoLabels = silent.GRABMETA(name,year)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img = iconimage
        if EnableFanArt == 'true':
                try:    fimg = infoLabels['backdrop_url']
                except: fimg = addon.get_fanart()
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        liz.setProperty( "Fanart_Image", fimg )
        ###Add to Library and Favorites Context Menu
        contextMenuItems = []
        if mode == 2:
                contextMenuItems = []
                contextMenuItems.append(('Add to Library', 'XBMC.RunPlugin(%s?mode=10&name=%s&url=%s)' % (sys.argv[0], name, urllib.quote_plus(url))))
        
                contextMenuItems.append(('Add to Favorites', 'XBMC.RunPlugin(%s?mode=14&name=%s&url=%s&year=%s)' % (sys.argv[0], name, urllib.quote_plus(url), year)))
                liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        ##############################
        ##############################
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addFAVDir(name,url,year):
        EnableFanArt = local.getSetting('Enable-Fanart')
        mode = 2
        types = 'Movie'
        ok=True
        type = types
        fimg = addon.get_fanart()
        if type != None:
                infoLabels = silent.GRABMETA(name,year)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img = iconimage
        if EnableFanArt == 'true':
                try:    fimg = infoLabels['backdrop_url']
                except: fimg = addon.get_fanart()
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        liz.setProperty( "Fanart_Image", fimg )
        ###Add to Library Context Menu
        contextMenuItems = []
        contextMenuItems.append(('Remove from Favorites', 'XBMC.RunPlugin(%s?mode=15&name=%s&url=%s&year=%s)' % (sys.argv[0], name, urllib.quote_plus(url), year)))
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ##############################
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

    
params=get_params()
url=None
name=None
mode=None
year=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        year=urllib.unquote_plus(params["year"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
        
elif mode==1:
        print ""+url
        INDEX(url)

elif mode==2:
        print ""+url
        VIDEOLINKS(name,url,year)

elif mode==3:
        print ""+url
        VIDEOLINKS2(name,url,year)

elif mode==4:
        print ""+url
        STREAM(name,url)

elif mode==5:
        print ""+url
        AZ(url)

elif mode==6:
        print ""+url
        SEARCH(url)

elif mode==7:
        print ""+url
        GETMYFAVS()

elif mode==8:
        print ""+url
        GENRES(url)

elif mode==9:
        print ""+url
        silent.DOWNLOAD(name,url)

elif mode==10:
        print ""+url
        silent.AddToLibrary(name,url)

elif mode==11:
        print ""+url
        silent.LIBRARYPLAY(name,url)

elif mode==12:
        print ""+url
        YEARFIND(url)

elif mode==13:
        print ""+url
        YEAR()

elif mode==14:
        print ""+url
        silent.addFavorite(name,url,year)

elif mode==15:
        print ""+url
        silent.removeFavorite(name,url,year)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
