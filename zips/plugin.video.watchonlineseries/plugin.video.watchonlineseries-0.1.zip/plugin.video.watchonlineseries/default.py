import urllib,urllib2,re,xbmcplugin,xbmcgui,urlresolver,xbmc,xbmcplugin,xbmcgui,xbmcaddon,os
from metahandler import metahandlers
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net


#www.watchonlineseries.eu/ - by The_Silencer 2013 v0.1


grab = metahandlers.MetaData(preparezip = False)
addon_id = 'plugin.video.watchonlineseries'
local = xbmcaddon.Addon(id=addon_id)
watchonlinepath = local.getAddonInfo('path')
addon = Addon(addon_id, sys.argv)
datapath = addon.get_profile()
art = watchonlinepath+'/art'
net = Net()
metaget = metahandlers.MetaData()


#Metahandler
def GRABMETA(name,types):
        type = types
        EnableMeta = local.getSetting('Enable-Meta')
        if EnableMeta == 'true':
                if 'Movie' in type:
                        meta = grab.get_meta('movie',name,'',None,None,overlay=6)
                        infoLabels = {'rating': meta['rating'],'duration': meta['duration'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],
                          'plot': meta['plot'],'title': meta['title'],'writer': meta['writer'],'cover_url': meta['cover_url'],
                          'director': meta['director'],'cast': meta['cast'],'backdrop_url': meta['backdrop_url'],'tmdb_id': meta['tmdb_id'],'year': meta['year']}
                elif 'tvshow' in type:
                        meta = grab.get_meta('tvshow',name,'','',None,overlay=6)
                        infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],
                              'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],
                              'cast': meta['cast'],'studio': meta['studio'],'banner_url': meta['banner_url'],
                              'backdrop_url': meta['backdrop_url'],'status': meta['status']}
        return infoLabels

def FAVORITES():
        xbmc.executebuiltin("ActivateWindow(favourites)")
        
                
#Main menu
def CATEGORIES():
        addDir('Featured TV Series','http://www.watchonlineseries.eu/',1,'',None)
        addDir('New Episodes','http://www.watchonlineseries.eu/new-shows',2,'',None)
        addDir('Top Watched Series','http://www.watchonlineseries.eu/',3,'',None)
        addDir('A-Z','http://www.watchonlineseries.eu/',4,'',None)
        #addDir('Search','http://www.watchonlineseries.eu/ajax/search.php',5,'',None)
        addDir('My Favorites','http://www.watchonlineseries.eu/',6,'',None)

#Featured TV Series list
def FEATURED(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<h2>\n<a href="(.+?)" title="(.+?)">.+?</a>\n</h2>').findall(net.http_GET(url).content)
        for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,url,7,'','tvshow')
                        if EnableMeta == 'false':
                                addDir(name,url,7,'',None)

#New Epidoes list
def NEW(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<h2>\n<a href="(.+?)" title=".+?">(.+?)</a>\n</h2>').findall(net.http_GET(url).content)
        for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,url,9,'','tvshow')
                        if EnableMeta == 'false':
                                addDir(name,url,9,'',None)

#Top Watched Series list
def TOP(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('\n.+?. <a title=".+?" href="(.+?)">(.+?)</a>').findall(net.http_GET(url).content)
        for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,'http://www.watchonlineseries.eu'+url,7,'','tvshow')
                        if EnableMeta == 'false':
                                addDir(name,'http://www.watchonlineseries.eu'+url,7,'',None)
                        
#A-Z list
def AZ(url):
        match=re.compile('<li class="menu-item"><a href="(.+?)">(.+?)</a></li>').findall(net.http_GET(url).content)
        for url,name in match:
                ok = ['0to9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'XtoZ']
                if name in ok:
                        addDir(name,url+'/abc',11,'',None)

#Routine to search for Movies
def SEARCH(url):
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search TV Shows from www.watchonlineseries.eu')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace('%20', '+')
                print encode
                data = net.http_POST(url,{'q' : encode, 'limit' : '5', 'verifiedCheck' : ''}).content#timestamp=1384445374090
                match=re.compile('<h2>\n<a href="(.+?)" title=".+?">(.+?)</a>\n</h2>').findall(data)  
                for url,name in match:
                        if EnableMeta == 'true':
                               addDir(name,url,9,'','tvshow')
                        if EnableMeta == 'false':
                               addDir(name,url,9,'',None)

#List TV Series
def INDEX(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<h2>\n<a href="(.+?)" title=".+?">(.+?)</a>\n</h2>').findall(net.http_GET(url).content)
        nextpage=re.search('<li><a href="(.+?)">&raquo;</a></li>',(net.http_GET(url).content))
        for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,url,7,'','tvshow')
                        if EnableMeta == 'false':
                                addDir(name,url,7,'',None)
        if nextpage:
                url = nextpage.group(1)
                if EnableMeta == 'true':
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',url+'/abc',11,'','tvshow')
                if EnableMeta == 'false':
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',url+'/abc',11,'',None)

#List the seasons
def SEASONS(url):
        match=re.compile('<a class="page-numbers current" href="(.+?)">(.+?)</a>').findall(net.http_GET(url).content)
        for url,name in match:
                addDir(name,url+'@'+name,8,'',None)

#List the episodes
def EPISODES(url):
        season = url.split('@')[1]
        url = url.split('@')[0]
        season = season+'.'
        match=re.compile('<h2>\n<a href="(.+?)" title=".+?">(.+?)</a>\n</h2>').findall(net.http_GET(url).content)
        for url,name in match:
                name = name.replace(season,'')
                if 'Episode' in name:
                        addDir(name,url,9,'',None)
                
#List the Hoster links
def VIDEOLINKS(url):
        match=re.compile('<span class="embed-type">\nEnglish\n-\n<strong>(.+?)</strong>\n</span>\n<div class="brokenlink">\n<a href="javascript:void\(0\);" class="right" onclick="reportEpisode\(\);">Broken Link</a>\n</div>\n<span class="embed-out-link">\n<a href="(.+?)"').findall(net.http_GET(url).content)
        for name,url in match:
                specialhost = ['iShared','allmyvideos.net','bestreams.net']
                if name not in specialhost:
                        addDir(name,url,10,'',None)
                else:
                        addDir(name,url,12,'',None)

#Resolve host not in metahandlers (iShared, ALLmyvideos, bestreams )
def SPECIALHOST(url,name):
        #Get iShared final link
        if 'iShared' in name:
                match=re.compile('path:"(.+?)"').findall(net.http_GET(url).content)
                for url in match:
                        addLink(name,url,'')

        #Get Allmyvideos final link
        if 'allmyvideos.net' in name:
                url = url+'.html'
                url = url.replace('http://allmyvideos.net/','http://allmyvideos.net/embed-')
                print url
                match=re.compile('{\n               "file" : "(.+?)".+?"label" : "(.+?)"',re.DOTALL).findall(net.http_GET(url).content)
                for url,quality in match:
                        addLink('%s : %s'%(name,quality),url,'')
                        
        #Get bestreams final link
        if 'bestreams' in name:
                url = url+'.html'
                url = url.replace('http://bestreams.net/','http://bestreams.net/embed-')
                print url
                match=re.compile('file: "(.+?)"').findall(net.http_GET(url).content)
                for url in match:
                        addLink(name,url,'')
                

#Pass url to urlresolver
def STREAM(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
        print streamlink
        url = streamlink
        addLink(name,streamlink,'')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok

def addDir(name,url,mode,iconimage,types):
        ok=True
        type = types
        if type != None:
                infoLabels = GRABMETA(name,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
    
params=get_params()
url=None
name=None
mode=None
queued=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        queued=params["queued"]
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
        
elif mode==1:
        print ""+url
        FEATURED(url)

elif mode==2:
        print ""+url
        NEW(url)

elif mode==3:
        print ""+url
        TOP(url)

elif mode==4:
        print ""+url
        AZ(url)

elif mode==5:
        print ""+url
        SEARCH(url)

elif mode==6:
        FAVORITES()

elif mode==7:
        print ""+url
        SEASONS(url)

elif mode==8:
        print ""+url
        EPISODES(url)

elif mode==9:
        print ""+url
        VIDEOLINKS(url)

elif mode==10:
        print ""+url
        STREAM(url)

elif mode==11:
        print ""+url
        INDEX(url)

elif mode==12:
        print ""+url
        SPECIALHOST(url,name)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
