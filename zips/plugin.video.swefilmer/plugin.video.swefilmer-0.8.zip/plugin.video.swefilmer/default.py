# -*- coding: cp1252 -*-
import urllib,urllib2,cookielib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os
from metahandler import metahandlers
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net


#swefilmer.com - by The_Silencer 2013 v0.8


grab = metahandlers.MetaData(preparezip = False)
addon_id = 'plugin.video.swefilmer'
local = xbmcaddon.Addon(id=addon_id)
lospath = local.getAddonInfo('path')
addon = Addon(addon_id, sys.argv)
datapath = addon.get_profile()
cookie_path = os.path.join(datapath)
art = lospath+'/art'
cookiejar = os.path.join(cookie_path,'swefilmer.lwp')
net = Net()
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

#Swefilmer.com login routine
def LOGON():
        swefilmer_account = local.getSetting('swefilmer-account')
        hide_message = local.getSetting('hide-successful-login-messages')
        if swefilmer_account == 'true':
                login = local.getSetting('swefilmer-username')
                password = local.getSetting('swefilmer-password')
                url='http://www.swefilmer.com/login.php'
                net.http_POST(url,{'username':login,'pass':password,'remember':'1','ref':'','Login':'Login'}).content
                net.save_cookies(cookiejar)
                        
#Metahandler
def GRABMETA(name,types):
        type = types
        EnableMeta = local.getSetting('Enable-Meta')
        if EnableMeta == 'true':
                if 'Movie' in type:
                        name = name.replace("[HD]",'')
                        meta = grab.get_meta('movie',name,'',None,None,overlay=6)
                        infoLabels = {'rating': meta['rating'],'duration': meta['duration'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],
                          'plot': meta['plot'],'title': meta['title'],'writer': meta['writer'],'cover_url': meta['cover_url'],
                          'director': meta['director'],'cast': meta['cast'],'backdrop_url': meta['backdrop_url'],'tmdb_id': meta['tmdb_id'],'year': meta['year']}
                        
                elif 'tvshow' in type:
                        meta = grab.get_meta('tvshow',name,'','',None,overlay=6)
                        infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],
                              'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],
                              'cast': meta['cast'],'studio': meta['studio'],'banner_url': meta['banner_url'],
                              'backdrop_url': meta['backdrop_url'],'status': meta['status']}
        return infoLabels

#Main menu
def CATEGORIES():
        LOGON()
        addDir('Top Videos','http://www.swefilmer.com/topvideos.html',5,'',None,'')
        addDir('New Videos','http://www.swefilmer.com/newvideos.html',5,'',None,'')
        addDir('Genres','http://www.swefilmer.com',9,'',None,'')
        addDir('Tv Series','http://www.swefilmer.com/browse-serier-videos-1-date.html',11,'',None,'')
        addDir('Search','http://www.swefilmer.com',10,'',None,'')

#Generes List
def GENRES():
        addDir('Dokumentar','http://www.swefilmer.com/browse-dokumentar-videos-1-date.html',6,'',None,'')
        addDir('Svenska','http://www.swefilmer.com/browse-svenska-videos-1-date.html',6,'',None,'')
        addDir('Romantik','http://www.swefilmer.com/browse-romantik-videos-1-date.html',6,'',None,'')
        addDir('Fantasy','http://www.swefilmer.com/browse-fantasy-videos-1-date.html',6,'',None,'')
        addDir('Aventyr','http://www.swefilmer.com/browse-aventyr-videos-1-date.html',6,'',None,'')
        addDir('Science Fiction','http://www.swefilmer.com/browse-Sciencefiction-videos-1-date.html',6,'',None,'')
        addDir('Komedi','http://www.swefilmer.com/browse-komedi-videos-1-date.html',6,'',None,'')
        addDir('Familjefilm','http://www.swefilmer.com/browse-familjefilm-videos-1-date.html',6,'',None,'')
        addDir('Western','http://www.swefilmer.com/browse-western-videos-1-date.html',6,'',None,'')
        addDir('Action','http://www.swefilmer.com/browse-action-videos-1-date.html',6,'',None,'')
        addDir('Kriminalare','http://www.swefilmer.com/browse-kriminalare-videos-1-date.html',6,'',None,'')
        addDir('Skrack','http://www.swefilmer.com/browse-Skrack-videos-1-date.html',6,'',None,'')
        addDir('Drama','http://www.swefilmer.com/browse-drama-videos-1-date.html',6,'',None,'')
        addDir('Kortfilm','http://www.swefilmer.com/browse-kortfilm-videos-1-date.html',6,'',None,'')
        addDir('Thriller','http://www.swefilmer.com/browse-thriller-videos-1-date.html',6,'',None,'')
        addDir('Animerad','http://www.swefilmer.com/browse-animerad-videos-1-date.html',6,'',None,'')
        addDir('Mysterium','http://www.swefilmer.com/browse-mysterium-videos-1-date.html',6,'',None,'')
        addDir('Krig','http://www.swefilmer.com/browse-krig-videos-1-date.html',6,'',None,'')
        addDir('Musikal','http://www.swefilmer.com/browse-musi-videos-1-date.html',6,'',None,'')
        addDir('Biografi','http://www.swefilmer.com/browse-biografi-videos-1-date.html',6,'',None,'')

#Scrape for Tv Series
def TV(url):
        swefilmer_account = local.getSetting('swefilmer-account')
        if swefilmer_account == 'true': 
                net.set_cookies(cookiejar)
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<li><a href="(.+?)">(.+?) \(.+?\)</a></li>').findall(net.http_GET(url).content)
        for url,name in match:
                if EnableMeta == 'true':
                        addDir(name.encode('UTF-8','ignore'),url,6,'','tvshow','')
                if EnableMeta == 'false':
                        addDir(name.encode('UTF-8','ignore'),url,6,'',None,'')

#Search Routine
def SEARCH():
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search swefilmer.com')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode=encode.replace('%20', '+')
                print encode
                surl='http://www.swefilmer.com/search.php?keywords='+encode+'&btn=S�k'
                print surl
                req = urllib2.Request(surl)
                req.add_header('User-Agent', USER_AGENT)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('<div class="video_i">\n<a href="(.+?)">\n<img src=".+?" alt="(.+?)"').findall(link)
                nextpage=re.search('<span class="current">.+?</span><a href="(.+?)">.+?</a>',(net.http_GET(surl).content))
                for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,url,7,'','Movie','')
                        if EnableMeta == 'false':
                                addDir(name,url,7,'',None,'')
                if nextpage:
                        url = nextpage.group(1)
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://www.swefilmer.com/'+url,6,'',None,'')

#Scrape for movies           
def INDEX1(url):
        swefilmer_account = local.getSetting('swefilmer-account')
        if swefilmer_account == 'true': 
                net.set_cookies(cookiejar)
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<td align="center" class=".+?" width="10"><a href="(.+?)"><img src=".+?" alt="(.+?)"').findall(net.http_GET(url).content)
        nextpage=re.search('<span class="current">.+?</span><a href="(.+?)">.+?</a>',(net.http_GET(url).content))
        for url,name in match:
                if EnableMeta == 'true':
                        addDir(name.encode('UTF-8','ignore'),url,7,'','Movie','')
                if EnableMeta == 'false':
                        addDir(name.encode('UTF-8','ignore'),url,7,'',None,'')
        if nextpage:
                url = nextpage.group(1)
                addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://www.swefilmer.com/'+url,5,'',None,'')

#Scrape for TV Series
def INDEX2(url):
        swefilmer_account = local.getSetting('swefilmer-account')
        if swefilmer_account == 'true':
                net.set_cookies(cookiejar)
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<div class="video_i">\n<a href="(.+?)">\n<img src=".+?" alt="(.+?)"').findall(net.http_GET(url).content)
        nextpage=re.search('<span class="current">.+?</span><a href="(.+?)">.+?</a>',(net.http_GET(url).content))
        for url,name in match:
                if EnableMeta == 'true':
                        addDir(name.encode('UTF-8','ignore'),url,7,'','Movie','')
                if EnableMeta == 'false':
                        addDir(name.encode('UTF-8','ignore'),url,7,'',None,'')
        if nextpage:
                url = nextpage.group(1)
                addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]','http://www.swefilmer.com/'+url,6,'',None,'')

#Scrape for video link
def VIDEOLINKS(url):
        swefilmer_account = local.getSetting('swefilmer-account')
        if swefilmer_account == 'true':
                net.set_cookies(cookiejar)
        match=re.compile('<iframe src="(.+?)" width="500" height="370" frameborder="0"></iframe>').findall(net.http_GET(url).content)
        login=re.compile('<div class="rv_warn">(.+?)</div>').findall(net.http_GET(url).content)
        if login:
                addDir('[B][COLOR yellow]Login Required for this video[/COLOR][/B]','http://www.swefilmer.com/','','',None,'')
        for url in match:
                url = url.replace('amp;', '')
                SPECIALHOST(url)
                                
#Resolve host VK
def SPECIALHOST(url):
        #Get VK final links with quality
        match720=re.search('url720=(.+?)&amp;',(net.http_GET(url).content))
        match480=re.search('url480=(.+?)&amp;',(net.http_GET(url).content))
        match360=re.search('url360=(.+?)&amp;',(net.http_GET(url).content))
        match260=re.search('url260=(.+?)&amp;',(net.http_GET(url).content))
        match240=re.search('url240=(.+?)&amp;',(net.http_GET(url).content))
        if match720:
                url = match720.group(1)
                url = url.replace('amp;', '')
                addLink('VK Quality : 720',url,'')
        if match480:
                url = match480.group(1)
                url = url.replace('amp;', '')
                addLink('VK Quality : 480',url,'')
        if match360:
                url = match360.group(1)
                url = url.replace('amp;', '')
                addLink('VK Quality : 360',url,'')
        if match260:
                url = match260.group(1)
                url = url.replace('amp;', '')
                addLink('VK Quality : 260',url,'')
        if match240:
                url = match240.group(1)
                url = url.replace('amp;', '')
                addLink('VK Quality : 240',url,'')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok


def addDir(name,url,mode,iconimage,types,year):
        ok=True
        type = types
        if type != None:
                infoLabels = GRABMETA(name,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels) 
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
    
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
        
elif mode==1:
        MOVIES()

elif mode==2:
        MOVIESAZ()

elif mode==3:
        MOVIESGEN()

elif mode==4:
        TVSHOWS()

elif mode==5:
        print ""+url
        INDEX1(url)

elif mode==6:
        print ""+url
        INDEX2(url)

elif mode==7:
        print ""+url
        VIDEOLINKS(url)

elif mode==8:
        print ""+url
        SPECIALHOST(url)

elif mode==9:
        GENRES()

elif mode==10:
        SEARCH()

elif mode==11:
        print ""+url
        TV(url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
