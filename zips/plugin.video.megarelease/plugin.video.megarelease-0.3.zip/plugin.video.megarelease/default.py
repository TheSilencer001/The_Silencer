import urllib,urllib2,cookielib,re,xbmcplugin,xbmcgui,xbmc,xbmcplugin,xbmcgui,xbmcaddon,os,sys,time
from metahandler import metahandlers
from addon.common.addon import Addon
from addon.common.net import Net


#megarelease.org - by The_Silencer 2013 v0.2


grab = metahandlers.MetaData(preparezip = False)
addon_id = 'plugin.video.megarelease'
local = xbmcaddon.Addon(id=addon_id)
lospath = local.getAddonInfo('path')
addon = Addon(addon_id, sys.argv)
datapath = addon.get_profile()
cookie_path = os.path.join(datapath)
cookiejar = os.path.join(cookie_path,'megarelease.lwp')
net = Net()
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

#megarelease.org login routine
def LOGON():
        megarelease_account = local.getSetting('megarelease-account')
        hide_message = local.getSetting('hide-successful-login-messages')
        if megarelease_account == 'true':
                login = local.getSetting('megarelease-username')
                password = local.getSetting('megarelease-password')
                
                #data = net.http_POST('http://megarelease.org/',{'op':'login','redirect':'http://megarelease.org/','login':login,'password':password}).content
                net.http_POST('http://megarelease.org/',{'op':'login','redirect':'http://megarelease.org/','login':login,'password':password}).content
                net.save_cookies(cookiejar)

                '''
                success = re.compile('<li><a href="/?op=my_account">(.+?)</a></li>.+?<li><a href="/?op=my_files">(.+?)</a></li>',re.DOTALL).findall(data)
                if success:
                        net.save_cookies(cookiejar)
                        if hide_message == 'false':
                                print 'Megarelease Account: login successful'
                                Notify('small','Megarelease', 'account login successful.',5000)
                if not success:
                        print 'Unrestrict Megarelease Account: login failed'
                        Notify('big','Megarelease','Login failed: check your username and password', '')
                '''

#Notifications
def Notify(typeq,title,message,times, line2='', line3=''):
     if typeq == 'small':
            smallicon= addon.get_icon()
            xbmc.executebuiltin("XBMC.Notification("+title+","+message+","''","+smallicon+")")
     elif typeq == 'big':
            dialog = xbmcgui.Dialog()
            dialog.ok(' '+title+' ', ' '+message+' ', line2, line3)
     else:
            dialog = xbmcgui.Dialog()
            dialog.ok(' '+title+' ', ' '+message+' ')

#Main menu
def CATEGORIES():
        LOGON()
        addDir('My Files','http://megarelease.org/?op=my_files',1,'',None,'')
        #Add any folders that might have been created
        INDEX2('http://megarelease.org/?op=my_files')

#Scrape for your files           
def INDEX1(url):
        net.set_cookies(cookiejar)
        match=re.compile('<TD><input type="checkbox" name="file_id" value=".+?"></TD>.+?<TD align=left><a href="(.+?)">(.+?)</a></TD>.+?<TD align=right>(.+?)</TD>',re.DOTALL).findall(net.http_GET(url).content)
        for url,name,size in match:
                addDir("%s  Size:%s" %(name,size),url,2,'',None,'')

#Scrape for user folders
def INDEX2(url):
        net.set_cookies(cookiejar)
        match=re.compile('<TD><img src="/images/folder.gif" alt="Folder"></TD>.+?<TD width="95%"><a href="(.+?)"><b>(.+?)</b></a></TD>',re.DOTALL).findall(net.http_GET(url).content)
        for url,name in match:
                url = url.replace('amp;', '')
                addDir(name,'http://megarelease.org/'+url,1,'',None,'')

#Resolve megarelease links Coded by: Eldorado
def resolve_megarelease(url):

    try:

        #Show dialog box so user knows something is happening
        dialog = xbmcgui.DialogProgress()
        dialog.create('Resolving', 'Resolving MegaRelease Link...')       
        dialog.update(0)
        
        print 'MegaRelease - Requesting GET URL: %s' % url
        html = net.http_GET(url).content
        
        dialog.update(50)
        
        #Check page for any error msgs
        if re.search('<b>File Not Found</b>', html):
            print '***** MegaRelease - File Not Found'
            raise Exception('File Not Found')

        #Set POST data values
        data = {}
        r = re.findall(r'type="hidden" name="(.+?)" value="(.+?)">', html)
        
        for name, value in r:
            data[name] = value

        captchaimg = re.search('<script type="text/javascript" src="(http://www.google.com.+?)">', html)
        
        if captchaimg:
            dialog.close()
            html = net.http_GET(captchaimg.group(1)).content
            part = re.search("challenge \: \\'(.+?)\\'", html)
            captchaimg = 'http://www.google.com/recaptcha/api/image?c='+part.group(1)
            img = xbmcgui.ControlImage(450,15,400,130,captchaimg)
            wdlg = xbmcgui.WindowDialog()
            wdlg.addControl(img)
            wdlg.show()
    
            time.sleep(3)
    
            kb = xbmc.Keyboard('', 'Type the letters in the image', False)
            kb.doModal()
            capcode = kb.getText()
    
            if (kb.isConfirmed()):
                userInput = kb.getText()
                if userInput != '':
                    solution = kb.getText()
                elif userInput == '':
                    Notify('big', 'No text entered', 'You must enter text in the image to access video', '')
                    return False
            else:
                return False
            wdlg.close()
            dialog.close() 
            dialog.create('Resolving', 'Resolving MegaRelease Link...') 
            dialog.update(50)
            data.update({'recaptcha_challenge_field':part.group(1),'recaptcha_response_field':solution})
        
        else:
            #Check for captcha
            captcha = re.compile("left:(\d+)px;padding-top:\d+px;'>&#(.+?);<").findall(html)
            if captcha:
                result = sorted(captcha, key=lambda ltr: int(ltr[0]))
                solution = ''.join(str(int(num[1])-48) for num in result)
            data.update({'code':solution})

        print 'MegaRelease - Requesting POST URL: %s DATA: %s' % (url, data)
        html = net.http_POST(url, data).content

        #Get download link
        dialog.update(100)
        link = re.search('<a href="(.+?)">Download', html)
        
        if link:
            print 'MegaRelease Link Found: %s' % link.group(1)
            link = link.group(1)
            addLink('Play',link,'')
        else:
            print '***** MegaRelease - Cannot find final link'
            raise Exception('Unable to resolve MegaRelease Link')

    except Exception, e:
        print '**** MegaRelease Error occured: %s' % e
        raise
    finally:
        dialog.close()
                                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok


def addDir(name,url,mode,iconimage,types,year):
        ok=True
        type = types
        if type != None:
                infoLabels = GRABMETA(name,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels) 
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
    
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
        
elif mode==1:
        print ""+url
        INDEX1(url)

elif mode==2:
        print ""+url
        resolve_megarelease(url)

elif mode==3:
        print ""+url
        INDEX2(url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
