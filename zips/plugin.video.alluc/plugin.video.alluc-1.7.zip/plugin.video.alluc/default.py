import urllib,urllib2,cookielib,base64,re,xbmcplugin,xbmcgui,urlresolver,xbmc,xbmcplugin,xbmcgui,xbmcaddon,sys,os
from metahandler import metahandlers
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net

#All You See (alluc.to) - by The_Silencer copyleft 2013 v1.7
#Art Work provided by azad720

#reload(sys) to fix error
reload(sys)

#Set default encoding to help handle non ascii characters
sys.setdefaultencoding('iso8859-1')

#Paths
addon_id = 'plugin.video.alluc'
local = xbmcaddon.Addon(id=addon_id)
allucpath = local.getAddonInfo('path')
addon = Addon(addon_id)
datapath = addon.get_profile()
cookie_path = os.path.join(datapath)
art = allucpath+'/art'
cookiejar = os.path.join(cookie_path,'alluc.lwp')
cookiejar1 = os.path.join(cookie_path,'un.lwp')

#Global constants
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
net = Net()
ALLUC_URL = 'http://www.alluc.to/'
ALLUC_FORUMS = 'http://board.alluc.to/'

#ALLUC Logon
def FINDSID(url):
        content = net.http_GET(url).content
        match=re.search('<input type="hidden" name="pageid" value="5" />\r\n\t\t<input type="hidden" name="sid" value="(.+?)" />\r\n\t\t<input type="hidden" name="sysparam" value="" />', content) #<input type="hidden" name="sid" value="(.+?)"
        return match.group(1)

def CHECKUSER(url):
        hide_message = local.getSetting('hide-successful-login-messages')
        net.set_cookies(cookiejar)
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('href="/logout.html">Logout (.+?)</a>').findall(link)
        if match:
                if hide_message == 'false':
                        print 'ALLUC Account: login successful'
                        Notify('small','ALLUC', 'Account login successful.',5000)
        if not match:
                print 'ALLUC Account: login failed'
                Notify('big','ALLUC','Login failed: check your username and password', '')
        pass

def LoginStartup():
        alluc_account = local.getSetting('alluc-account')
        hide_message = local.getSetting('hide-successful-login-messages')
        if alluc_account == 'true':
                loginurl = ALLUC_URL
                login = local.getSetting('alluc-username')
                password = local.getSetting('alluc-password')
                
                sid = FINDSID(loginurl)
                form = {'action' : 'login_out_box', 'loginid' : login, 'passwd' : password, 'remember' : '1', 'pageid' : '5', 'sid' : sid}
                
                net.http_POST(loginurl, form)
                net.save_cookies(cookiejar)        
                CHECKUSER(ALLUC_URL)

#Notifications
def Notify(typeq,title,message,times, line2='', line3=''):
     if typeq == 'small':
          xbmc.executebuiltin("XBMC.Notification("+title+","+message+","''","''")")
     elif typeq == 'big':
          dialog = xbmcgui.Dialog()
          dialog.ok(' '+title+' ', ' '+message+' ', line2, line3)
     else:
          dialog = xbmcgui.Dialog()
          dialog.ok(' '+title+' ', ' '+message+' ')

#Metahandlers
grab = metahandlers.MetaData(preparezip = False)
def GRABMETA(name,types,year):
        type = types
        EnableMeta = local.getSetting('Enable-Meta')       
        if EnableMeta == 'true':
                if 'Movie' in type:
                        meta = grab.get_meta('movie',name,year,'',None,overlay=6)
                        infoLabels = {'rating': meta['rating'],'duration': meta['duration'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],
                          'plot': meta['plot'],'title': meta['title'],'writer': meta['writer'],'cover_url': meta['cover_url'],
                          'director': meta['director'],'cast': meta['cast'],'backdrop_url': meta['backdrop_url'],'tmdb_id': meta['tmdb_id'],'year': meta['year']}
                elif 'tvshow' in type:
                        meta = grab.get_meta('tvshow',name,year,'',None,overlay=6)
                        infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],
                              'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],
                              'cast': meta['cast'],'studio': meta['studio'],'banner_url': meta['banner_url'],
                              'backdrop_url': meta['backdrop_url'],'status': meta['status']}
        return infoLabels
                

#Menus
def CATEGORIES():
        LoginStartup()
        alluc_account = local.getSetting('alluc-account')
        HideXXX = local.getSetting('Hide-XXX')
        
        addDir('Movies',ALLUC_URL,1,os.path.join(art,'movies.png'),None,'')
        addDir('TV-SHOWS',ALLUC_URL,4,os.path.join(art,'tv-shows.png'),None,'')
        addDir('Anime',ALLUC_URL,5,os.path.join(art,'anime.png'),None,'')
        addDir('Cartoons',ALLUC_URL,6,os.path.join(art,'cartoons.png'),None,'')
        addDir('Documentaries',ALLUC_URL,7,os.path.join(art,'documentaries.png'),None,'')
        addDir('Sports',ALLUC_URL,10,os.path.join(art,'sports.png'),None,'')
        if HideXXX == 'false':
                addDir('XXX',ALLUC_URL+'adult.html?',21,os.path.join(art,'xxx.png'),None,'')
        addDir('Search',ALLUC_FORUMS,51,os.path.join(art,'search.png'),None,'')
        addDir('New Forum Links *BETA*',ALLUC_FORUMS,44,os.path.join(art,'forum.png'),None,'')
        addDir('','','','',None,'')
        if alluc_account == 'true':
                #addDir('Check Login Status','http://alluc.to',13,'',None,'') #Check for ALLUC username for troubleshooting
                
                #Check for new messages before adding Messagebox menu
                net.set_cookies(cookiejar)
                req = urllib2.Request(ALLUC_URL)
                req.add_header('User-Agent', USER_AGENT)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('title="Your Profile">Your Profile (.+?)</a></div>').findall(link)
                if match:
                        addDir('My Messagebox'+str(match),ALLUC_URL+'member-messagebox.html',37,os.path.join(art,'messagebox.png'),None,'')
                if not match:
                        addDir('My Messagebox',ALLUC_URL+'member-messagebox.html',37,os.path.join(art,'messagebox.png'),None,'')
                addDir('My Watchlist',ALLUC_URL+'watchlist.html',40,os.path.join(art,'watchlist.png'),None,'')
                addDir('Top 50 from Other Watchlist','http://www.alluc.to/watchlist.html?mode=top',39,os.path.join(art,'top-50.png'),None,'')

def FORUMS():
        addDir('New Movie Links',ALLUC_FORUMS+'forumdisplay.php?fid=30',45,os.path.join(art,'updated.png'),None,'')
        addDir('New TV-Show Links',ALLUC_FORUMS+'forumdisplay.php?fid=13',46,os.path.join(art,'updated.png'),None,'')
        addDir('New Documentaries Links',ALLUC_FORUMS+'forumdisplay.php?fid=31',47,os.path.join(art,'updated.png'),None,'')

def MOVIES():
        addDir('A-Z',ALLUC_URL+'movies.html',2,os.path.join(art,'a-z.png'),None,'')
        addDir('Genres',ALLUC_URL,3,os.path.join(art,'genres.png'),None,'')
        addDir('Actors',ALLUC_URL+'movies.html?mode=allactors',53,os.path.join(art,'actors.png'),None,'')
        addDir('Featured Movies',ALLUC_URL+'movies.html',25,os.path.join(art,'featured.png'),None,'')
        addDir('Updated Movies',ALLUC_URL+'movies.html?mode=updated',14,os.path.join(art,'updated.png'),None,'')
        addDir('Popular Movies',ALLUC_URL+'movies.html',14,os.path.join(art,'popular.png'),None,'')
        addDir('Search Movies',ALLUC_URL+'movies.html',28,os.path.join(art,'search.png'),None,'')

def ACTORSDIR():
        addDir('A-Z',ALLUC_URL+'movies.html?mode=allactors',54,os.path.join(art,'a-z.png'),None,'')
        addDir('Search Actors',ALLUC_URL+'movies.html?mode=allactors',55,os.path.join(art,'search.png'),None,'')
        
def ACTORSAZ():
        addDir('A',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('B',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('C',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('D',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('E',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('F',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('G',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('H',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('I',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('J',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('K',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('L',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('M',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('N',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('O',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('P',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('Q',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('R',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('S',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('T',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('U',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('V',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('W',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('X',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('Y',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        addDir('Z',ALLUC_URL+'movies.html?mode=allactors',49,'',None,'')
        
def ACTORSEARCH():
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search ALLUC for Actors')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                search = str(search).replace(' ','+')
                encode=urllib.quote(search)
                surl=ALLUC_URL+'movies/actor/'+encode+''
                req = urllib2.Request(surl)
                req.add_header('User-Agent', USER_AGENT)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('href="(.+?)" title="watch (.+?)\s\(([\d]{4})\) online"').findall(link)
                for url,name,year in match:
                        if EnableMeta == 'true':
                                addDir(name,ALLUC_URL+url,18,'','Movie',year)
                        if EnableMeta == 'false':
                                addDir(name,ALLUC_URL+url,18,'',None,year)

def MOVIESAZ():
        addDir('#',ALLUC_URL+'movies.html?mode=showall&letter=%23',14,'',None,'')
        addDir('A',ALLUC_URL+'movies.html?mode=showall&letter=A',14,'',None,'')
        addDir('B',ALLUC_URL+'movies.html?mode=showall&letter=B',14,'',None,'')
        addDir('C',ALLUC_URL+'movies.html?mode=showall&letter=C',14,'',None,'')
        addDir('D',ALLUC_URL+'movies.html?mode=showall&letter=D',14,'',None,'')
        addDir('E',ALLUC_URL+'movies.html?mode=showall&letter=E',14,'',None,'')
        addDir('F',ALLUC_URL+'movies.html?mode=showall&letter=F',14,'',None,'')
        addDir('G',ALLUC_URL+'movies.html?mode=showall&letter=G',14,'',None,'')
        addDir('H',ALLUC_URL+'movies.html?mode=showall&letter=H',14,'',None,'')
        addDir('I',ALLUC_URL+'movies.html?mode=showall&letter=I',14,'',None,'')
        addDir('J',ALLUC_URL+'movies.html?mode=showall&letter=J',14,'',None,'')
        addDir('K',ALLUC_URL+'movies.html?mode=showall&letter=K',14,'',None,'')
        addDir('L',ALLUC_URL+'movies.html?mode=showall&letter=L',14,'',None,'')
        addDir('M',ALLUC_URL+'movies.html?mode=showall&letter=M',14,'',None,'')
        addDir('N',ALLUC_URL+'movies.html?mode=showall&letter=N',14,'',None,'')
        addDir('O',ALLUC_URL+'movies.html?mode=showall&letter=O',14,'',None,'')
        addDir('P',ALLUC_URL+'movies.html?mode=showall&letter=P',14,'',None,'')
        addDir('Q',ALLUC_URL+'movies.html?mode=showall&letter=Q',14,'',None,'')
        addDir('R',ALLUC_URL+'movies.html?mode=showall&letter=R',14,'',None,'')
        addDir('S',ALLUC_URL+'movies.html?mode=showall&letter=S',14,'',None,'')
        addDir('T',ALLUC_URL+'movies.html?mode=showall&letter=T',14,'',None,'')
        addDir('U',ALLUC_URL+'movies.html?mode=showall&letter=U',14,'',None,'')
        addDir('V',ALLUC_URL+'movies.html?mode=showall&letter=V',14,'',None,'')
        addDir('W',ALLUC_URL+'movies.html?mode=showall&letter=W',14,'',None,'')
        addDir('X',ALLUC_URL+'movies.html?mode=showall&letter=X',14,'',None,'')
        addDir('Y',ALLUC_URL+'movies.html?mode=showall&letter=Y',14,'',None,'')
        addDir('Z',ALLUC_URL+'movies.html?mode=showall&letter=Z',14,'',None,'')

def MOVIESGEN():
        addDir('Action',ALLUC_URL+'movies/action/3462.html',14,'',None,'')
        addDir('Adventure',ALLUC_URL+'movies/adventure/3468.html',14,'',None,'')
        addDir('Animated',ALLUC_URL+'movies/animated/195775.html',14,'',None,'')
        addDir('Animation',ALLUC_URL+'movies/animation/4169.html',14,'',None,'')
        addDir('Anime',ALLUC_URL+'movies/anime/44334.html',14,'',None,'')
        addDir('Biography',ALLUC_URL+'movies/biography/26737.html',14,'',None,'')
        addDir('Bollywood(English)',ALLUC_URL+'movies/bollywoodenglish/50636.html',14,'',None,'')
        addDir('Bollywood(Hindi)',ALLUC_URL+'movies/bollywoodhindi/51348.html',14,'',None,'')
        addDir('Christmas',ALLUC_URL+'movies/christmas/438811.html',14,'',None,'')
        addDir('Comedy',ALLUC_URL+'movies/comedy/3463.html',14,'',None,'')
        addDir('Crime',ALLUC_URL+'movies/crime/13170.html',14,'',None,'')
        addDir('Culture',ALLUC_URL+'movies/culture/301612.html',14,'',None,'')
        addDir('Dance',ALLUC_URL+'movies/dance/120895.html',14,'',None,'')
        addDir('Disaster',ALLUC_URL+'movies/disaster/172417.html',14,'',None,'')
        addDir('Documentary',ALLUC_URL+'movies/documentary/171297.html',14,'',None,'')
        addDir('Drama',ALLUC_URL+'movies/drama/3472.html',14,'',None,'')
        addDir('Drugs',ALLUC_URL+'movies/drugs/129862.html',14,'',None,'')
        addDir('Epic',ALLUC_URL+'movies/epic/172430.html',14,'',None,'')
        addDir('Family',ALLUC_URL+'movies/family/6141.html',14,'',None,'')
        addDir('Fantasy',ALLUC_URL+'movies/fantasy/3580.html',14,'',None,'')
        addDir('Foreign',ALLUC_URL+'movies/foreign/172445.html',14,'',None,'')
        addDir('Gay & Lesbian',ALLUC_URL+'movies/gay-and-lesbian/40536.html',14,'',None,'')
        addDir('Gore',ALLUC_URL+'movies/gore/134650.html',14,'',None,'')
        addDir('History',ALLUC_URL+'movies/history/3474.html',14,'',None,'')
        addDir('Horror',ALLUC_URL+'movies/horror/3476.html',14,'',None,'')
        addDir('Iranian',ALLUC_URL+'movies/iranian/438733.html',14,'',None,'')
        addDir('Martial Arts',ALLUC_URL+'movies/martial-arts/56600.html',14,'',None,'')
        addDir('Murder',ALLUC_URL+'movies/murder/171062.html',14,'',None,'')
        addDir('Music',ALLUC_URL+'movies/music/8470.html',14,'',None,'')
        addDir('Musical',ALLUC_URL+'movies/musical/3478.html',14,'',None,'')
        addDir('Mystery',ALLUC_URL+'movies/mystery/16572.html',14,'',None,'')
        addDir('Romance',ALLUC_URL+'movies/romance/4898.html',14,'',None,'')
        addDir('Science Fiction',ALLUC_URL+'movies/science-fiction/3480.html',14,'',None,'')
        addDir('Short Fims',ALLUC_URL+'movies/short-films/9007.html',14,'',None,'')
        addDir('Sport',ALLUC_URL+'movies/sport/6337.html',14,'',None,'')
        addDir('Suspense',ALLUC_URL+'movies/suspense/172492.html',14,'',None,'')
        addDir('Thriller',ALLUC_URL+'movies/thriller/4078.html',14,'',None,'')
        addDir('War',ALLUC_URL+'movies/war/3482.html',14,'',None,'')
        addDir('Western',ALLUC_URL+'movies/western/3484.html',14,'',None,'')

def TVSHOWS():
        addDir('A-Z',ALLUC_URL,19,os.path.join(art,'a-z.png'),None,'')
        addDir('Actors',ALLUC_URL+'tv-shows.html?mode=allactors',49,os.path.join(art,'actors.png'),None,'')
        addDir('Featured TV-SHOWS',ALLUC_URL+'tv-shows.html',26,os.path.join(art,'featured.png'),None,'')
        addDir('Updated TV-SHOWS',ALLUC_URL+'tv-shows.html?mode=updated',15,os.path.join(art,'updated.png'),None,'')
        addDir('Popular TV-SHOWS',ALLUC_URL+'tv-shows.html',15,os.path.join(art,'popular.png'),None,'')
        addDir('Search TV-SHOWS',ALLUC_URL+'tv-shows.html',29,os.path.join(art,'search.png'),None,'')

def TVSHOWSAZ():
        addDir('#',ALLUC_URL+'tv-shows.html?mode=showall&letter=%23',15,'',None,'')
        addDir('A',ALLUC_URL+'tv-shows.html?mode=showall&letter=A',15,'',None,'')
        addDir('B',ALLUC_URL+'tv-shows.html?mode=showall&letter=B',15,'',None,'')
        addDir('C',ALLUC_URL+'tv-shows.html?mode=showall&letter=C',15,'',None,'')
        addDir('D',ALLUC_URL+'tv-shows.html?mode=showall&letter=D',15,'',None,'')
        addDir('E',ALLUC_URL+'tv-shows.html?mode=showall&letter=E',15,'',None,'')
        addDir('F',ALLUC_URL+'tv-shows.html?mode=showall&letter=F',15,'',None,'')
        addDir('G',ALLUC_URL+'tv-shows.html?mode=showall&letter=G',15,'',None,'')
        addDir('H',ALLUC_URL+'tv-shows.html?mode=showall&letter=H',15,'',None,'')
        addDir('I',ALLUC_URL+'tv-shows.html?mode=showall&letter=I',15,'',None,'')
        addDir('J',ALLUC_URL+'tv-shows.html?mode=showall&letter=J',15,'',None,'')
        addDir('K',ALLUC_URL+'tv-shows.html?mode=showall&letter=K',15,'',None,'')
        addDir('L',ALLUC_URL+'tv-shows.html?mode=showall&letter=L',15,'',None,'')
        addDir('M',ALLUC_URL+'tv-shows.html?mode=showall&letter=M',15,'',None,'')
        addDir('N',ALLUC_URL+'tv-shows.html?mode=showall&letter=N',15,'',None,'')
        addDir('O',ALLUC_URL+'tv-shows.html?mode=showall&letter=O',15,'',None,'')
        addDir('P',ALLUC_URL+'tv-shows.html?mode=showall&letter=P',15,'',None,'')
        addDir('Q',ALLUC_URL+'tv-shows.html?mode=showall&letter=Q',15,'',None,'')
        addDir('R',ALLUC_URL+'tv-shows.html?mode=showall&letter=R',15,'',None,'')
        addDir('S',ALLUC_URL+'tv-shows.html?mode=showall&letter=S',15,'',None,'')
        addDir('T',ALLUC_URL+'tv-shows.html?mode=showall&letter=T',15,'',None,'')
        addDir('U',ALLUC_URL+'tv-shows.html?mode=showall&letter=U',15,'',None,'')
        addDir('V',ALLUC_URL+'tv-shows.html?mode=showall&letter=V',15,'',None,'')
        addDir('W',ALLUC_URL+'tv-shows.html?mode=showall&letter=W',15,'',None,'')
        addDir('X',ALLUC_URL+'tv-shows.html?mode=showall&letter=X',15,'',None,'')
        addDir('Y',ALLUC_URL+'tv-shows.html?mode=showall&letter=Y',15,'',None,'')
        addDir('Z',ALLUC_URL+'tv-shows.html?mode=showall&letter=Z',15,'',None,'')

def ANIME():
        addDir('A-Z',ALLUC_URL+'anime.html',30,os.path.join(art,'a-z.png'),None,'')
        addDir('Search Anime',ALLUC_URL+'anime.html',31,os.path.join(art,'search.png'),None,'')

def ANIMEAZ():
        addDir('#',ALLUC_URL+'anime.html?mode=showall&letter=%23',15,'',None,'')
        addDir('A',ALLUC_URL+'anime.html?mode=showall&letter=A',15,'',None,'')
        addDir('B',ALLUC_URL+'anime.html?mode=showall&letter=B',15,'',None,'')
        addDir('C',ALLUC_URL+'anime.html?mode=showall&letter=C',15,'',None,'')
        addDir('D',ALLUC_URL+'anime.html?mode=showall&letter=D',15,'',None,'')
        addDir('E',ALLUC_URL+'anime.html?mode=showall&letter=E',15,'',None,'')
        addDir('F',ALLUC_URL+'anime.html?mode=showall&letter=F',15,'',None,'')
        addDir('G',ALLUC_URL+'anime.html?mode=showall&letter=G',15,'',None,'')
        addDir('H',ALLUC_URL+'anime.html?mode=showall&letter=H',15,'',None,'')
        addDir('I',ALLUC_URL+'anime.html?mode=showall&letter=I',15,'',None,'')
        addDir('J',ALLUC_URL+'anime.html?mode=showall&letter=J',15,'',None,'')
        addDir('K',ALLUC_URL+'anime.html?mode=showall&letter=K',15,'',None,'')
        addDir('L',ALLUC_URL+'anime.html?mode=showall&letter=L',15,'',None,'')
        addDir('M',ALLUC_URL+'anime.html?mode=showall&letter=M',15,'',None,'')
        addDir('N',ALLUC_URL+'anime.html?mode=showall&letter=N',15,'',None,'')
        addDir('O',ALLUC_URL+'anime.html?mode=showall&letter=O',15,'',None,'')
        addDir('P',ALLUC_URL+'anime.html?mode=showall&letter=P',15,'',None,'')
        addDir('Q',ALLUC_URL+'anime.html?mode=showall&letter=Q',15,'',None,'')
        addDir('R',ALLUC_URL+'anime.html?mode=showall&letter=R',15,'',None,'')
        addDir('S',ALLUC_URL+'anime.html?mode=showall&letter=S',15,'',None,'')
        addDir('T',ALLUC_URL+'anime.html?mode=showall&letter=T',15,'',None,'')
        addDir('U',ALLUC_URL+'anime.html?mode=showall&letter=U',15,'',None,'')
        addDir('V',ALLUC_URL+'anime.html?mode=showall&letter=V',15,'',None,'')
        addDir('W',ALLUC_URL+'anime.html?mode=showall&letter=W',15,'',None,'')
        addDir('X',ALLUC_URL+'anime.html?mode=showall&letter=X',15,'',None,'')
        addDir('Y',ALLUC_URL+'anime.html?mode=showall&letter=Y',15,'',None,'')
        addDir('Z',ALLUC_URL+'anime.html?mode=showall&letter=Z',15,'',None,'')

def CARTOONS():
        addDir('A-Z',ALLUC_URL+'anime.html',32,os.path.join(art,'a-z.png'),None,'')
        addDir('Search Cartoons',ALLUC_URL+'anime.html',33,os.path.join(art,'search.png'),None,'')
        
def CARTOONSAZ():
        addDir('#',ALLUC_URL+'cartoons.html?mode=showall&letter=%23',15,'',None,'')
        addDir('A',ALLUC_URL+'cartoons.html?mode=showall&letter=A',15,'',None,'')
        addDir('B',ALLUC_URL+'cartoons.html?mode=showall&letter=B',15,'',None,'')
        addDir('C',ALLUC_URL+'cartoons.html?mode=showall&letter=C',15,'',None,'')
        addDir('D',ALLUC_URL+'cartoons.html?mode=showall&letter=D',15,'',None,'')
        addDir('E',ALLUC_URL+'cartoons.html?mode=showall&letter=E',15,'',None,'')
        addDir('F',ALLUC_URL+'cartoons.html?mode=showall&letter=F',15,'',None,'')
        addDir('G',ALLUC_URL+'cartoons.html?mode=showall&letter=G',15,'',None,'')
        addDir('H',ALLUC_URL+'cartoons.html?mode=showall&letter=H',15,'',None,'')
        addDir('I',ALLUC_URL+'cartoons.html?mode=showall&letter=I',15,'',None,'')
        addDir('J',ALLUC_URL+'cartoons.html?mode=showall&letter=J',15,'',None,'')
        addDir('K',ALLUC_URL+'cartoons.html?mode=showall&letter=K',15,'',None,'')
        addDir('L',ALLUC_URL+'cartoons.html?mode=showall&letter=L',15,'',None,'')
        addDir('M',ALLUC_URL+'cartoons.html?mode=showall&letter=M',15,'',None,'')
        addDir('N',ALLUC_URL+'cartoons.html?mode=showall&letter=N',15,'',None,'')
        addDir('O',ALLUC_URL+'cartoons.html?mode=showall&letter=O',15,'',None,'')
        addDir('P',ALLUC_URL+'cartoons.html?mode=showall&letter=P',15,'',None,'')
        addDir('Q',ALLUC_URL+'cartoons.html?mode=showall&letter=Q',15,'',None,'')
        addDir('R',ALLUC_URL+'cartoons.html?mode=showall&letter=R',15,'',None,'')
        addDir('S',ALLUC_URL+'cartoons.html?mode=showall&letter=S',15,'',None,'')
        addDir('T',ALLUC_URL+'cartoons.html?mode=showall&letter=T',15,'',None,'')
        addDir('U',ALLUC_URL+'cartoons.html?mode=showall&letter=U',15,'',None,'')
        addDir('V',ALLUC_URL+'cartoons.html?mode=showall&letter=V',15,'',None,'')
        addDir('W',ALLUC_URL+'cartoons.html?mode=showall&letter=W',15,'',None,'')
        addDir('X',ALLUC_URL+'cartoons.html?mode=showall&letter=X',15,'',None,'')
        addDir('Y',ALLUC_URL+'cartoons.html?mode=showall&letter=Y',15,'',None,'')
        addDir('Z',ALLUC_URL+'cartoons.html?mode=showall&letter=Z',15,'',None,'')
        
def DOCUMENTARIES():
        addDir('A-Z',ALLUC_URL,8,os.path.join(art,'a-z.png'),None,'')
        addDir('Genres',ALLUC_URL,9,os.path.join(art,'genres.png'),None,'')
        addDir('Search Documentaries',ALLUC_URL,34,os.path.join(art,'search.png'),None,'')

def DOCUMENTARIESAZ():
        addDir('#',ALLUC_URL+'documentaries.html?mode=showall&letter=%23',14,'',None,'')
        addDir('A',ALLUC_URL+'documentaries.html?mode=showall&letter=A',14,'',None,'')
        addDir('B',ALLUC_URL+'documentaries.html?mode=showall&letter=B',14,'',None,'')
        addDir('C',ALLUC_URL+'documentaries.html?mode=showall&letter=C',14,'',None,'')
        addDir('D',ALLUC_URL+'documentaries.html?mode=showall&letter=D',14,'',None,'')
        addDir('E',ALLUC_URL+'documentaries.html?mode=showall&letter=E',14,'',None,'')
        addDir('F',ALLUC_URL+'documentaries.html?mode=showall&letter=F',14,'',None,'')
        addDir('G',ALLUC_URL+'documentaries.html?mode=showall&letter=G',14,'',None,'')
        addDir('H',ALLUC_URL+'documentaries.html?mode=showall&letter=H',14,'',None,'')
        addDir('I',ALLUC_URL+'documentaries.html?mode=showall&letter=I',14,'',None,'')
        addDir('J',ALLUC_URL+'documentaries.html?mode=showall&letter=J',14,'',None,'')
        addDir('K',ALLUC_URL+'documentaries.html?mode=showall&letter=K',14,'',None,'')
        addDir('L',ALLUC_URL+'documentaries.html?mode=showall&letter=L',14,'',None,'')
        addDir('M',ALLUC_URL+'documentaries.html?mode=showall&letter=M',14,'',None,'')
        addDir('N',ALLUC_URL+'documentaries.html?mode=showall&letter=N',14,'',None,'')
        addDir('O',ALLUC_URL+'documentaries.html?mode=showall&letter=O',14,'',None,'')
        addDir('P',ALLUC_URL+'documentaries.html?mode=showall&letter=P',14,'',None,'')
        addDir('Q',ALLUC_URL+'documentaries.html?mode=showall&letter=Q',14,'',None,'')
        addDir('R',ALLUC_URL+'documentaries.html?mode=showall&letter=R',14,'',None,'')
        addDir('S',ALLUC_URL+'documentaries.html?mode=showall&letter=S',14,'',None,'')
        addDir('T',ALLUC_URL+'documentaries.html?mode=showall&letter=T',14,'',None,'')
        addDir('U',ALLUC_URL+'documentaries.html?mode=showall&letter=U',14,'',None,'')
        addDir('V',ALLUC_URL+'documentaries.html?mode=showall&letter=V',14,'',None,'')
        addDir('W',ALLUC_URL+'documentaries.html?mode=showall&letter=W',14,'',None,'')
        addDir('X',ALLUC_URL+'documentaries.html?mode=showall&letter=X',14,'',None,'')
        addDir('Y',ALLUC_URL+'documentaries.html?mode=showall&letter=Y',14,'',None,'')
        addDir('Z',ALLUC_URL+'documentaries.html?mode=showall&letter=Z',14,'',None,'')

def DOCUMENTARIESGEN():
        addDir('20-20 My Secret Self',ALLUC_URL+'documentaries/20-20-my-secret-self/29362.html',14,'',None,'')
        addDir('9-11',ALLUC_URL+'documentaries/9-11/15601.html',14,'',None,'')
        addDir('Action',ALLUC_URL+'documentaries/action/300262.html',14,'',None,'')
        addDir('Animals',ALLUC_URL+'documentaries/animals/15605.html',14,'',None,'')
        addDir('Animation',ALLUC_URL+'documentaries/animation/133919.html',14,'',None,'')
        addDir('Arthur Clarke',ALLUC_URL+'documentaries/arthur-c-clarke/26350.html',14,'',None,'')
        addDir('Barack Hussein Obama',ALLUC_URL+'documentaries/barack-hussein-obama/50481.html',14,'',None,'')
        addDir('BBC Horizon',ALLUC_URL+'documentaries/bbc-horizon/20221.html',14,'',None,'')
        addDir('BBC Lost Worlds',ALLUC_URL+'documentaries/bbc-lost-worlds/24359.html',14,'',None,'')
        addDir('BBC Walking With Cavemen',ALLUC_URL+'documentaries/bbc-walking-with-cavemen/59819.html',14,'',None,'')
        addDir('BBC Wildlife',ALLUC_URL+'documentaries/bbc-wildlife/24310.html',14,'',None,'')
        addDir('Biography',ALLUC_URL+'documentaries/biography/15608.html',14,'',None,'')
        addDir('Carrier',ALLUC_URL+'documentaries/carrier/44803.html',14,'',None,'')
        addDir('Celebrity',ALLUC_URL+'documentaries/celebrity/47739.html',14,'',None,'')
        addDir('Civil Liberties',ALLUC_URL+'documentaries/civil-liberties/24597.html',14,'',None,'')
        addDir('Computer',ALLUC_URL+'documentaries/computer/22992.html',14,'',None,'')
        addDir('Conspiracy Theories',ALLUC_URL+'documentaries/conspiracy-theories/15610.html',14,'',None,'')
        addDir('Crime',ALLUC_URL+'documentaries/crime/15625.html',14,'',None,'')
        addDir('Culture',ALLUC_URL+'documentaries/culture/25359.html',14,'',None,'')
        addDir('Culture Asia',ALLUC_URL+'documentaries/culture-asia/38836.html',14,'',None,'')
        addDir('Discovery Channel Presents',ALLUC_URL+'documentaries/discovery-channel-presents/49601.html',14,'',None,'')
        addDir('Dispatched Fighting the Taliban',ALLUC_URL+'documentaries/dispatched-fighting-the-taliban/47211.html',14,'',None,'')
        addDir('Doctor Who Confidential',ALLUC_URL+'documentaries/doctor-who-confidential/38882.html',14,'',None,'')
        addDir('Documentaries',ALLUC_URL+'documentaries/documentaries/25024.html',14,'',None,'')
        addDir('Drama',ALLUC_URL+'documentaries/drama/300224.html',14,'',None,'')
        addDir('Drink',ALLUC_URL+'documentaries/drink/45881.html',14,'',None,'')
        addDir('Drugs',ALLUC_URL+'documentaries/drugs/15614.html',14,'',None,'')
        addDir('Ecology',ALLUC_URL+'documentaries/ecology/24445.html',14,'',None,'')
        addDir('Extreme Engineering',ALLUC_URL+'documentaries/extreme-engineering/24874.html',14,'',None,'')
        addDir('Family',ALLUC_URL+'documentaries/family/352715.html',14,'',None,'')
        addDir('Gaming',ALLUC_URL+'documentaries/gaming/16747.html',14,'',None,'')
        addDir('Gay & Lesbian',ALLUC_URL+'documentaries/gay-and-lesbian/48920.html',14,'',None,'')
        addDir('Global Warming',ALLUC_URL+'documentaries/global-warming/133838.html',14,'',None,'')
        addDir('Growing up in the Universe',ALLUC_URL+'documentaries/growing-up-in-the-uiniverse/45928.html',14,'',None,'')
        addDir('Guantanamo',ALLUC_URL+'documentaries/guantanamo/24608.html',14,'',None,'')
        addDir('Health',ALLUC_URL+'documentaries/health/15711.html',14,'',None,'')
        addDir('History',ALLUC_URL+'documentaries/history/171300.html',14,'',None,'')
        addDir('Horror',ALLUC_URL+'documentaries/horror/372675.html',14,'',None,'')
        addDir('Illiminati / Space',ALLUC_URL+'documentaries/illuminati-space/42732.html',14,'',None,'')
        addDir('Investigative',ALLUC_URL+'documentaries/investigative/39528.html',14,'',None,'')
        addDir('The IRA',ALLUC_URL+'documentaries/ira-the/28684.html',14,'',None,'')
        addDir('Iraq War',ALLUC_URL+'documentaries/iraq-war/24648.html',14,'',None,'')
        addDir('Isreal',ALLUC_URL+'documentaries/isreal/24633.html',14,'',None,'')
        addDir('Jane Goodall',ALLUC_URL+'documentaries/jane-goodall/24322.html',14,'',None,'')
        addDir('Larry King Live',ALLUC_URL+'documentaries/larry-king-live/53974.html',14,'',None,'')
        addDir('Life',ALLUC_URL+'documentaries/life/185625.html',14,'',None,'')
        addDir('Lifestyle',ALLUC_URL+'documentaries/lifestyle/15888.html',14,'',None,'')
        addDir('Literary Analysis',ALLUC_URL+'documentaries/literary-analysis/23216.html',14,'',None,'')
        addDir('Living',ALLUC_URL+'documentaries/living/15857.html',14,'',None,'')
        addDir('Lost Civilizations',ALLUC_URL+'documentaries/lost-civilizations/15827.html',14,'',None,'')
        addDir('Martial Arts',ALLUC_URL+'documentaries/martial-arts/111939.html',14,'',None,'')
        addDir('Movies',ALLUC_URL+'documentaries/movies/22249.html',14,'',None,'')
        addDir('Music',ALLUC_URL+'documentaries/music/15949.html',14,'',None,'')
        addDir('Mystery',ALLUC_URL+'documentaries/mystery/369491.html',14,'',None,'')
        addDir('Myth',ALLUC_URL+'documentaries/myth/29444.html',14,'',None,'')
        addDir('National Geographic',ALLUC_URL+'documentaries/national-geographic/44392.html',14,'',None,'')
        addDir('Nature',ALLUC_URL+'documentaries/nature/24457.html',14,'',None,'')
        addDir('Occult',ALLUC_URL+'documentaries/occult/25159.html',14,'',None,'')
        addDir('Paranormal',ALLUC_URL+'documentaries/paranormal/39958.html',14,'',None,'')
        addDir('Parascience',ALLUC_URL+'documentaries/parascience/49708.html',14,'',None,'')
        addDir('PBS Nova',ALLUC_URL+'documentaries/pbs-nova/52311.html',14,'',None,'')
        addDir('Plants',ALLUC_URL+'documentaries/plants/185626.html',14,'',None,'')
        addDir('Politics',ALLUC_URL+'documentaries/politics/15606.html',14,'',None,'')
        addDir('Porography Addiction',ALLUC_URL+'documentaries/pornography-addiction/49848.html',14,'',None,'')
        addDir('Real Football Factories',ALLUC_URL+'documentaries/real-football-factories-international/37216.html',14,'',None,'')
        addDir('Religion',ALLUC_URL+'documentaries/religion/15599.html',14,'',None,'')
        addDir('Science',ALLUC_URL+'documentaries/science/17252.html',14,'',None,'')
        addDir('Seconds from Disaster',ALLUC_URL+'documentaries/seconds-from-disaster/29454.html',14,'',None,'')
        addDir('Short Films',ALLUC_URL+'documentaries/short-films-films/300235.html',14,'',None,'')
        addDir('Sport',ALLUC_URL+'documentaries/sport/26423.html',14,'',None,'')
        addDir('Technology',ALLUC_URL+'documentaries/technology/24831.html',14,'',None,'')
        addDir('Television',ALLUC_URL+'documentaries/television/24878.html',14,'',None,'')
        addDir('Terrorism',ALLUC_URL+'documentaries/terrorism/15613.html',14,'',None,'')
        addDir('Thriller',ALLUC_URL+'documentaries/thriller/352695.html',14,'',None,'')
        addDir('Torchwood Declassified',ALLUC_URL+'documentaries/torchwood-declassified/38880.html',14,'',None,'')
        addDir('UFO',ALLUC_URL+'documentaries/ufo/24437.html',14,'',None,'')
        addDir('The Universe',ALLUC_URL+'documentaries/universe-the/29959.html',14,'',None,'')
        addDir('Venezuela',ALLUC_URL+'documentaries/venezuela/28735.html',14,'',None,'')
        addDir('War',ALLUC_URL+'documentaries/war/17373.html',14,'',None,'')

def SPORTS():
        addDir('A-Z',ALLUC_URL,11,os.path.join(art,'a-z.png'),None,'')
        addDir('Genres',ALLUC_URL,12,os.path.join(art,'genres.png'),None,'')

def SPORTSAZ():
        addDir('#',ALLUC_URL+'sport.html?mode=showall&letter=%23',16,'',None,'')
        addDir('A',ALLUC_URL+'sport.html?mode=showall&letter=A',14,'',None,'')
        addDir('B',ALLUC_URL+'sport.html?mode=showall&letter=B',14,'',None,'')
        addDir('C',ALLUC_URL+'sport.html?mode=showall&letter=C',14,'',None,'')
        addDir('D',ALLUC_URL+'sport.html?mode=showall&letter=D',14,'',None,'')
        addDir('E',ALLUC_URL+'sport.html?mode=showall&letter=E',14,'',None,'')
        addDir('F',ALLUC_URL+'sport.html?mode=showall&letter=F',14,'',None,'')
        addDir('G',ALLUC_URL+'sport.html?mode=showall&letter=G',14,'',None,'')
        addDir('H',ALLUC_URL+'sport.html?mode=showall&letter=H',14,'',None,'')
        addDir('I',ALLUC_URL+'sport.html?mode=showall&letter=I',14,'',None,'')
        addDir('J',ALLUC_URL+'sport.html?mode=showall&letter=J',14,'',None,'')
        addDir('K',ALLUC_URL+'sport.html?mode=showall&letter=K',14,'',None,'')
        addDir('L',ALLUC_URL+'sport.html?mode=showall&letter=L',14,'',None,'')
        addDir('M',ALLUC_URL+'sport.html?mode=showall&letter=M',14,'',None,'')
        addDir('N',ALLUC_URL+'sport.html?mode=showall&letter=N',14,'',None,'')
        addDir('O',ALLUC_URL+'sport.html?mode=showall&letter=O',14,'',None,'')
        addDir('P',ALLUC_URL+'sport.html?mode=showall&letter=P',14,'',None,'')
        addDir('Q',ALLUC_URL+'sport.html?mode=showall&letter=Q',14,'',None,'')
        addDir('R',ALLUC_URL+'sport.html?mode=showall&letter=R',14,'',None,'')
        addDir('S',ALLUC_URL+'sport.html?mode=showall&letter=S',14,'',None,'')
        addDir('T',ALLUC_URL+'sport.html?mode=showall&letter=T',14,'',None,'')
        addDir('U',ALLUC_URL+'sport.html?mode=showall&letter=U',14,'',None,'')
        addDir('V',ALLUC_URL+'sport.html?mode=showall&letter=V',14,'',None,'')
        addDir('W',ALLUC_URL+'sport.html?mode=showall&letter=W',14,'',None,'')
        addDir('X',ALLUC_URL+'sport.html?mode=showall&letter=X',14,'',None,'')
        addDir('Y',ALLUC_URL+'sport.html?mode=showall&letter=Y',14,'',None,'')
        addDir('Z',ALLUC_URL+'sport.html?mode=showall&letter=Z',14,'',None,'')

def SPORTSGEN():
        addDir('Accidents',ALLUC_URL+'sport/accidents/5952.html',14,'',None,'')
        addDir('Action',ALLUC_URL+'sport/action/374527.html',14,'',None,'')
        addDir('Alpine Skiing',ALLUC_URL+'sport/alpine-skiing/6231.html',14,'',None,'')
        addDir('AND 1 mix tapes',ALLUC_URL+'sport/and-1-mix-tapes/59924.html',14,'',None,'')
        addDir('Arsenal',ALLUC_URL+'sport/arsenal/39714.html',14,'',None,'')
        addDir('Badminton',ALLUC_URL+'sport/badminton/21090.html',14,'',None,'')
        addDir('Baseball',ALLUC_URL+'sport/baseball/6224.html',14,'',None,'')
        addDir('Basketball',ALLUC_URL+'sport/basketball/6052.html',14,'',None,'')
        addDir('BMX',ALLUC_URL+'sport/bmx/6260.html',14,'',None,'')
        addDir('Bowling',ALLUC_URL+'sport/bowling/25166.html',14,'',None,'')
        addDir('Breakdance',ALLUC_URL+'sport/breakdance/7536.html',14,'',None,'')
        addDir('Cricket',ALLUC_URL+'sport/cricket/6074.html',14,'',None,'')
        addDir('Documentary',ALLUC_URL+'sport/documentary/374535.html',14,'',None,'')
        addDir('European Poker Tour',ALLUC_URL+'sport/european-poker-tour/14959.html',14,'',None,'')
        addDir('Extreme Sports',ALLUC_URL+'sport/extreme-sports/17036.html',14,'',None,'')
        addDir('Field Hockey',ALLUC_URL+'sport/fieldhockey/6146.html',14,'',None,'')
        addDir('Fishing',ALLUC_URL+'sport/fishing/6283.html',14,'',None,'')
        addDir('Football',ALLUC_URL+'sport/football/6058.html',14,'',None,'')
        addDir('Football - USA',ALLUC_URL+'sport/football-usa-nfl-college-etc/6220.html',14,'',None,'')
        addDir('Football - UK',ALLUC_URL+'sport/football-uk/12629.html',14,'',None,'')
        addDir('Formula 1',ALLUC_URL+'sport/formula-1/6093.html',14,'',None,'')
        addDir('Gaelic Football',ALLUC_URL+'sport/gaelic-football-ireland/6169.html',14,'',None,'')
        addDir('Golf',ALLUC_URL+'sport/golf/6106.html',14,'',None,'')
        addDir('Grappling',ALLUC_URL+'sport/grappling/23914.html',14,'',None,'')
        addDir('Gymnastics',ALLUC_URL+'sport/gymnastics/21382.html',14,'',None,'')
        addDir('Handball',ALLUC_URL+'sport/handball/6181.html',14,'',None,'')
        addDir('Hockey',ALLUC_URL+'sport/hockey/6126.html',14,'',None,'')
        addDir('Lacrosse',ALLUC_URL+'sport/lacrosse-general/6279.html',14,'',None,'')
        addDir('Lancer De Canetles',ALLUC_URL+'sport/lancer-de-canettes/10046.html',14,'',None,'')
        addDir('Martial Arts',ALLUC_URL+'sport/martial-arts/6800.html',14,'',None,'')
        addDir('Motor Sport',ALLUC_URL+'sport/motorsport/6088.html',14,'',None,'')
        addDir('Paintball',ALLUC_URL+'sport/paintball/7740.html',14,'',None,'')
        addDir('Parkour',ALLUC_URL+'sport/parkour/6353.html',14,'',None,'')
        addDir('Poker',ALLUC_URL+'sport/poker/700.html',14,'',None,'')
        addDir('Police Take Downs',ALLUC_URL+'sport/police-take-downs/39691.html',14,'',None,'')
        addDir('Roller Derby',ALLUC_URL+'sport/roller-derby/48157.html',14,'',None,'')
        addDir('Rugby',ALLUC_URL+'sport/rugby/6308.html',14,'',None,'')
        addDir('Shooting',ALLUC_URL+'sport/shooting/6111.html',14,'',None,'')
        addDir('Skateboarding',ALLUC_URL+'sport/skateboarding/6523.html',14,'',None,'')
        addDir('Skiing',ALLUC_URL+'sport/skiing/10941.html',14,'',None,'')
        addDir('Snooker/Pool',ALLUC_URL+'sport/snooker-pool/6082.html',14,'',None,'')
        addDir('Soccer',ALLUC_URL+'sport/soccer/6050.html',14,'',None,'')
        addDir('Sport',ALLUC_URL+'sport/sport/301487.html',14,'',None,'')
        addDir('Summer Olympics',ALLUC_URL+'sport/summer-olympics/6188.html',14,'',None,'')
        addDir('Sumo',ALLUC_URL+'sport/sumo/6047.html',14,'',None,'')
        addDir('Table Tennis',ALLUC_URL+'sport/table-tennis/20405.html',14,'',None,'')
        addDir('Tennis',ALLUC_URL+'sport/tennis/6101.html',14,'',None,'')
        addDir('UFC',ALLUC_URL+'sport/ufc/6437.html',14,'',None,'')
        addDir('Weight Lifiting',ALLUC_URL+'sport/weight-lifting/6268.html',14,'',None,'')
        addDir('Winter Olumpics',ALLUC_URL+'sport/winter-olympics/6178.html',14,'',None,'')
        addDir('Wrestling',ALLUC_URL+'sport/wrestling/888.html',14,'',None,'')
        addDir('WWE No Way Out',ALLUC_URL+'sport/wwe-no-way-out/39675.html',14,'',None,'')
        addDir('WWF/WWE',ALLUC_URL+'sport/wwf-wwe/15730.html',14,'',None,'')
        addDir('Yoga',ALLUC_URL+'sport/yoga/25460.html',14,'',None,'')

def ADULT():
        addDir('A-Z',ALLUC_URL,23,os.path.join(art,'a-z.png'),None,'')
        addDir('Genres',ALLUC_URL,24,os.path.join(art,'genres.png'),None,'')
        addDir('Pornstars',ALLUC_URL+'adult.html?mode=allactors',49,os.path.join(art,'pornstars.png'),None,'')
        addDir('Updated XXX',ALLUC_URL+'adult.html?mode=updated',14,os.path.join(art,'updated.png'),None,'')
        addDir('Popular XXX',ALLUC_URL+'adult.html?mode=popular',14,os.path.join(art,'popular.png'),None,'')
        addDir('Search XXX',ALLUC_URL+'adult.html',35,os.path.join(art,'search.png'),None,'')

def ADULTAZ():
        addDir('#',ALLUC_URL+'adult.html?mode=showall&letter=%23',14,'',None,'')
        addDir('A',ALLUC_URL+'adult.html?mode=showall&letter=A',14,'',None,'')
        addDir('B',ALLUC_URL+'adult.html?mode=showall&letter=B',14,'',None,'')
        addDir('C',ALLUC_URL+'adult.html?mode=showall&letter=C',14,'',None,'')
        addDir('D',ALLUC_URL+'adult.html?mode=showall&letter=D',14,'',None,'')
        addDir('E',ALLUC_URL+'adult.html?mode=showall&letter=E',14,'',None,'')
        addDir('F',ALLUC_URL+'adult.html?mode=showall&letter=F',14,'',None,'')
        addDir('G',ALLUC_URL+'adult.html?mode=showall&letter=G',14,'',None,'')
        addDir('H',ALLUC_URL+'adult.html?mode=showall&letter=H',14,'',None,'')
        addDir('I',ALLUC_URL+'adult.html?mode=showall&letter=I',14,'',None,'')
        addDir('J',ALLUC_URL+'adult.html?mode=showall&letter=J',14,'',None,'')
        addDir('K',ALLUC_URL+'adult.html?mode=showall&letter=K',14,'',None,'')
        addDir('L',ALLUC_URL+'adult.html?mode=showall&letter=L',14,'',None,'')
        addDir('M',ALLUC_URL+'adult.html?mode=showall&letter=M',14,'',None,'')
        addDir('N',ALLUC_URL+'adult.html?mode=showall&letter=N',14,'',None,'')
        addDir('O',ALLUC_URL+'adult.html?mode=showall&letter=O',14,'',None,'')
        addDir('P',ALLUC_URL+'adult.html?mode=showall&letter=P',14,'',None,'')
        addDir('Q',ALLUC_URL+'adult.html?mode=showall&letter=Q',14,'',None,'')
        addDir('R',ALLUC_URL+'adult.html?mode=showall&letter=R',14,'',None,'')
        addDir('S',ALLUC_URL+'adult.html?mode=showall&letter=S',14,'',None,'')
        addDir('T',ALLUC_URL+'adult.html?mode=showall&letter=T',14,'',None,'')
        addDir('U',ALLUC_URL+'adult.html?mode=showall&letter=U',14,'',None,'')
        addDir('V',ALLUC_URL+'adult.html?mode=showall&letter=V',14,'',None,'')
        addDir('W',ALLUC_URL+'adult.html?mode=showall&letter=W',14,'',None,'')
        addDir('X',ALLUC_URL+'adult.html?mode=showall&letter=X',14,'',None,'')
        addDir('Y',ALLUC_URL+'adult.html?mode=showall&letter=Y',14,'',None,'')
        addDir('Z',ALLUC_URL+'adult.html?mode=showall&letter=Z',14,'',None,'')

def ADULTGEN():
        addDir('Amature',ALLUC_URL+'adult/amateur/90001.html',14,'',None,'')
        addDir('Anal',ALLUC_URL+'adult/anal/90002.html',14,'',None,'')
        addDir('Anime',ALLUC_URL+'adult/anime/90003.html',14,'',None,'')
        addDir('Asians',ALLUC_URL+'adult/asians/90004.html',14,'',None,'')
        addDir('Babes',ALLUC_URL+'adult/babes/90006.html',14,'',None,'')
        addDir('BBW',ALLUC_URL+'adult/bbw/90013.html',14,'',None,'')
        addDir('BDSM',ALLUC_URL+'adult/bdsm/445095.html',14,'',None,'')
        addDir('Big Cocks',ALLUC_URL+'adult/big-cocks/445110.html',14,'',None,'')
        addDir('Big Tits',ALLUC_URL+'adult/big-tits/90007.html',14,'',None,'')
        addDir('Black',ALLUC_URL+'adult/black/445102.html',14,'',None,'')
        addDir('Blondes',ALLUC_URL+'adult/blondes/90008.html',14,'',None,'')
        addDir('Blow Jobs',ALLUC_URL+'adult/blowjob/90009.html',14,'',None,'')
        addDir('Booty',ALLUC_URL+'adult/booty/90005.html',14,'',None,'')
        addDir('Brunette',ALLUC_URL+'adult/brunette/449535.html',14,'',None,'')
        addDir('Bukkake',ALLUC_URL+'adult/bukkake/445099.html',14,'',None,'')
        addDir('Celebrities',ALLUC_URL+'adult/celebrities/90011.html',14,'',None,'')
        addDir('Classic',ALLUC_URL+'adult/classic-porn/449547.html',14,'',None,'')
        addDir('Creampie',ALLUC_URL+'adult/creampie/444982.html',14,'',None,'')
        addDir('Cumshots',ALLUC_URL+'adult/cumshots/445101.html',14,'',None,'')
        addDir('Deep Throat',ALLUC_URL+'adult/deep-throat/444988.html',14,'',None,'')
        addDir('Double Pen',ALLUC_URL+'adult/dp/444720.html',14,'',None,'')
        addDir('Ebony',ALLUC_URL+'adult/ebony/90012.html',14,'',None,'')
        addDir('Facials',ALLUC_URL+'adult/facials/444738.html',14,'',None,'')
        addDir('Feature',ALLUC_URL+'adult/feature/449546.html',14,'',None,'')
        addDir('Fetish',ALLUC_URL+'adult/fetish/444732.html',14,'',None,'')
        addDir('Foot Job',ALLUC_URL+'adult/footjob/90014.html',14,'',None,'')
        addDir('Gangbang',ALLUC_URL+'adult/gangbang/444709.html',14,'',None,'')
        addDir('German',ALLUC_URL+'adult/german/444730.html',14,'',None,'')
        addDir('Gonzo',ALLUC_URL+'adult/gonzo/444995.html',14,'',None,'')
        addDir('Groupsex',ALLUC_URL+'adult/groupsex/90016.html',14,'',None,'')
        addDir('Handjobs',ALLUC_URL+'adult/handjobs/444981.html',14,'',None,'')
        addDir('Hardcore',ALLUC_URL+'adult/hardcore/90017.html',14,'',None,'')
        addDir('Interracial',ALLUC_URL+'adult/interracial/449537.html',14,'',None,'')
        addDir('Latinas',ALLUC_URL+'adult/latinas/90018.html',14,'',None,'')
        addDir('Lesbians',ALLUC_URL+'adult/lesbians/90019.html',14,'',None,'')
        addDir('Masturbation',ALLUC_URL+'adult/masturbation/444731.html',14,'',None,'')
        addDir('Mature',ALLUC_URL+'adult/mature/444721.html',14,'',None,'')
        addDir('MILF',ALLUC_URL+'adult/milf/444719.html',14,'',None,'')
        addDir('Natural',ALLUC_URL+'adult/natural/444737.html',14,'',None,'')
        addDir('Newcomers',ALLUC_URL+'adult/newcomers/444986.html',14,'',None,'')
        addDir('Outdoor',ALLUC_URL+'adult/outdoor/445096.html',14,'',None,'')
        addDir('Pornstars',ALLUC_URL+'adult/pornstars/90021.html',14,'',None,'')
        addDir('POV',ALLUC_URL+'adult/pov/90022.html',14,'',None,'')
        addDir('Reality',ALLUC_URL+'adult/reality/445232.html',14,'',None,'')
        addDir('Roleplay',ALLUC_URL+'adult/roleplay/449541.html',14,'',None,'')
        addDir('Schoolgirls',ALLUC_URL+'adult/schoolgirls/90023.html',14,'',None,'')
        addDir('Small Tits',ALLUC_URL+'adult/small-tits/449534.html',14,'',None,'')
        addDir('Softcore',ALLUC_URL+'adult/softcore/444722.html',14,'',None,'')
        addDir('Solo',ALLUC_URL+'adult/solo/450835.html',14,'',None,'')
        addDir('Squirting',ALLUC_URL+'adult/squirting/444727.html',14,'',None,'')
        addDir('Swallowing',ALLUC_URL+'adult/swallowing/449542.html',14,'',None,'')
        addDir('Tattooed',ALLUC_URL+'adult/tattooed/449538.html',14,'',None,'')
        addDir('Teens',ALLUC_URL+'adult/teens/90024.html',14,'',None,'')
        addDir('Threesomes',ALLUC_URL+'adult/threesomes/444717.html',14,'',None,'')
        addDir('Tit Fucking',ALLUC_URL+'adult/tit-fucking/449544.html',14,'',None,'')
        addDir('Toys',ALLUC_URL+'adult/toys/90025.html',14,'',None,'')
        addDir('Transsexual',ALLUC_URL+'adult/transsexual/449543.html',14,'',None,'')
        addDir('Unsorted',ALLUC_URL+'adult/unsorted/90026.html',14,'',None,'')

#Search
def SEARCH(url):
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search ALLUC')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                surl=ALLUC_URL+'search.html?sword='+encode+''
                req = urllib2.Request(surl)
                req.add_header('User-Agent', USER_AGENT)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('<a class="newlinks" href="(.+?)" title="watch (.+?) online"').findall(link)
                for url,name in match:
                        if 'tv-shows' in url:
                                if EnableMeta == 'true':
                                        addDir(name,ALLUC_URL+url,16,'','tvshow','')
                                if EnableMeta == 'false':
                                        addDir(name,ALLUC_URL+url,16,'',None,'')
                        if 'cartoons' in url:
                                if EnableMeta == 'true':
                                        addDir(name,ALLUC_URL+url,16,'','tvshow','')
                                if EnableMeta == 'false':
                                        addDir(name,ALLUC_URL+url,16,'',None,'')
                        if 'anime' in url:
                                if EnableMeta == 'true':
                                        addDir(name,ALLUC_URL+url,16,'','tvshow','')
                                if EnableMeta == 'false':
                                        addDir(name,ALLUC_URL+url,16,'',None,'')
                        else:
                                if EnableMeta == 'true':
                                        addDir(name,ALLUC_URL+url,18,'','Movie','')
                                if EnableMeta == 'false':
                                        addDir(name,ALLUC_URL+url,18,'',None,'')

def SEARCHMOVIES():
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search ALLUC for Movies')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                surl=ALLUC_URL+'movies.html?mode=search&filter=&sort=&sword='+encode+''
                req = urllib2.Request(surl)
                req.add_header('User-Agent', USER_AGENT)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('<a class="newlinks" href="(.+?)" title="watch (.+?) online"').findall(link)
                for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,ALLUC_URL+url,18,'','Movie','')
                        if EnableMeta == 'false':
                                addDir(name,ALLUC_URL+url,18,'',None,'')

def SEARCHTV():
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search ALLUC for TV-Shows')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                surl=ALLUC_URL+'tv-shows.html?mode=search&filter=&sort=&sword='+encode+''
                req = urllib2.Request(surl)
                req.add_header('User-Agent', USER_AGENT)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('<a class="newlinks" href="(.+?)" title="watch (.+?) online"').findall(link)
                for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,ALLUC_URL+url,16,'','tvshow','')
                        if EnableMeta == 'false':
                                addDir(name,ALLUC_URL+url,16,'',None,'')

def SEARCHANIME():
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search ALLUC for TV-Shows')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                surl=ALLUC_URL+'anime.html?mode=search&filter=&sort=&sword='+encode+''
                req = urllib2.Request(surl)
                req.add_header('User-Agent', USER_AGENT)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('<a class="newlinks" href="(.+?)" title="watch (.+?) online"').findall(link)
                for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,ALLUC_URL+url,16,'','tvshow','')
                        if EnableMeta == 'false':
                                addDir(name,ALLUC_URL+url,16,'',None,'')
                                
def SEARCHCARTOON():
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search ALLUC for Cartoons')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                surl=ALLUC_URL+'cartoon.html?mode=search&filter=&sort=&sword='+encode+''
                req = urllib2.Request(surl)
                req.add_header('User-Agent', USER_AGENT)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('<a class="newlinks" href="(.+?)" title="watch (.+?) online"').findall(link)
                for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,ALLUC_URL+url,16,'','tvshow','')
                        if EnableMeta == 'false':
                                addDir(name,ALLUC_URL+url,16,'',None,'')

def SEARCHDOCUMENTARIES():
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search ALLUC for Documentaries')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                surl=ALLUC_URL+'documentaries.html?mode=search&filter=&sort=&sword='+encode+''
                req = urllib2.Request(surl)
                req.add_header('User-Agent', USER_AGENT)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('<a class="newlinks" href="(.+?)" title="watch (.+?) online"').findall(link)
                for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,ALLUC_URL+url,18,'','Movie','')
                        if EnableMeta == 'false':
                                addDir(name,ALLUC_URL+url,18,'',None,'')

def SEARCHADULT():
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search ALLUC for XXX')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                surl=ALLUC_URL+'adult.html?mode=search&filter=&sort=&sword='+encode+''
                req = urllib2.Request(surl)
                req.add_header('User-Agent', USER_AGENT)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('<a class="newlinks" href="(.+?)" title="watch (.+?) online"').findall(link)
                for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,ALLUC_URL+url,18,'','Movie','')
                        if EnableMeta == 'false':
                                addDir(name,ALLUC_URL+url,18,'',None,'')

#After login routines
def INDEX1(url):
        net.set_cookies(cookiejar)
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('href="/logout.html">Logout (.+?)</a>').findall(link)
        for name in match:
               addDir('Logged in as: '+name,url,18,'',None,None)

def NEWMESSAGES(url):
        net.set_cookies(cookiejar)
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('title="Your Profile">Your Profile (.+?)</a></div>').findall(link)
        return match

def MESSAGES(url):
        net.set_cookies(cookiejar)
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<td class="msgsubjecteven"><a class="messageboxlink" href="(.+?)">(.+?)</a></td>.+?<a class="messageboxlink" href=".+?">(.+?)</a></td>.+?<td class="msgdateeven">(.+?)</td>',re.DOTALL).findall(link)#<a class="messageboxlink" href="(.+?)">(.+?)</a></td>.+?<a class="messageboxlink" href=".+?">(.+?)</a></td>
        for url,name,user,date in match:
                addDir("Subject: %s      From: %s        Date: %s"%(name,user,date),'http://www.alluc.to'+url,38,'',None,None)

def READMESSAGES(url):
        net.set_cookies(cookiejar)
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<div style="font-size:12px;width:768px;overflow:hidden;background-color:#fff;color:#000;padding:4px 4px 4px 4px;">(.+?)</div>',re.DOTALL).findall(link)
        for name in match:
               addDir(name,url,18,'',None,None)

def MYWATCHLIST(url):
        net.set_cookies(cookiejar)
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<div class="deflist" style="width:520px">.+?href="(.+?)".+?onmouseout=".+?".+?>(.+?)</a>',re.DOTALL).findall(link)
        #match = str(match).replace('&gt;','>')
        for url,name in match:
               addDir(name,ALLUC_URL+url,20,'',None,None)
        
def OTHERWATCHLIST(url):
        EnableMeta = local.getSetting('Enable-Meta')
        net.set_cookies(cookiejar)
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<td class=".+?" style="width:15px;text-align:right;">(.+?).</td>.+?<a href="(.+?)".+?onmouseover=".+?".+?onmousemove=".+?".+?onmouseout=".+?".+?>(.+?)</a>',re.DOTALL).findall(link)
        #match = str(match).replace('&gt;',' ')
        for rank,url,name in match:
                if 'season' in url:
                        addDir("# %s  %s"%(rank,name),ALLUC_URL+url,17,'',None,'')
                if 'tv-shows' in url:
                        if EnableMeta == 'true':
                                addDir("# %s  %s"%(rank,name),ALLUC_URL+url,16,'','tvshow','')
                        if EnableMeta == 'false':
                                addDir("# %s  %s"%(rank,name),ALLUC_URL+url,16,'',None,'')
                if 'cartoons' in url:
                        if EnableMeta == 'true':
                                addDir("# %s  %s"%(rank,name),ALLUC_URL+url,16,'','tvshow','')
                        if EnableMeta == 'false':
                                addDir("# %s  %s"%(rank,name),ALLUC_URL+url,16,'',None,'')
                if 'anime' in url:
                        if EnableMeta == 'true':
                                addDir("# %s  %s"%(rank,name),ALLUC_URL+url,16,'','tvshow','')
                        if EnableMeta == 'false':
                                addDir("# %s  %s"%(rank,name),ALLUC_URL+url,16,'',None,'')
                else:
                        if EnableMeta == 'true':
                                addDir("# %s  %s"%(rank,name),ALLUC_URL+url,18,'','Movie','')
                        if EnableMeta == 'false':
                                addDir("# %s  %s"%(rank,name),ALLUC_URL+url,18,'',None,'')
               
#Movies              
def INDEX2(url):
        EnableMeta = local.getSetting('Enable-Meta')
        if EnableMeta == 'true': dialog = 'Please wait while Metadata is added.'
        if EnableMeta == 'false': dialog = 'Please wait while Movie list is created.'
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<li class="linklist2">\r\n\t\t\t\t\t<a href="(.+?)" title="watch (.+?)\s\(([\d]{4})\) online">').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create(dialog)
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Movies loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'',remaining_display)
        for url,name, year in match:
                if EnableMeta == 'true':
                        addDir(name,ALLUC_URL+url,18,'','Movie',year)
                if EnableMeta == 'false':
                        addDir(name,ALLUC_URL+url,18,'',None,year)
                loadedLinks = loadedLinks + 1
                percent = (loadedLinks * 100)/totalLinks
                remaining_display = 'Movies loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
                dialogWait.update(percent,'',remaining_display)
                if (dialogWait.iscanceled()):
                        return False
        dialogWait.close()
        del dialogWait

#TV-SHOWS       
def INDEX3(url):
        EnableMeta = local.getSetting('Enable-Meta')
        if EnableMeta == 'true': dialog = 'Please wait while Metadata is added.'
        if EnableMeta == 'false': dialog = 'Please wait while Tv-Show list is created.'
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<li class="linklist2">\r\n\t\t\t\t\t<a href="(.+?)" title="watch (.+?)\s\(([\d]{4})\) online">').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create(dialog)
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Tv-Shows loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'',remaining_display)
        for url,name,year in match:
                if EnableMeta == 'true':
                        addDir(name,ALLUC_URL+url,16,'','tvshow',year)
                if EnableMeta == 'false':
                        addDir(name,ALLUC_URL+url,16,'',None,year)
                loadedLinks = loadedLinks + 1
                percent = (loadedLinks * 100)/totalLinks
                remaining_display = 'Tv-Shows loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
                dialogWait.update(percent,'',remaining_display)
                if (dialogWait.iscanceled()):
                        return False
        dialogWait.close()
        del dialogWait

#Featured Movies
def FEATURED(url):
        EnableMeta = local.getSetting('Enable-Meta')
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)" class="featuredlink" title=""\r\n\t\t\t\tonmouseover="vorschau\(\\\'ttfeatured\\\',true,\\\'(.+?)\s\(([\d]{4})\)').findall(link)
        for url,name,year in match:
                if EnableMeta == 'true':
                        addDir(name,url,18,'','Movie',year)
                if EnableMeta == 'false':
                        addDir(name,url,18,'',None,year)

#Featured TV-Shows
def FEATUREDTV(url):
        EnableMeta = local.getSetting('Enable-Meta')
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)" class="featuredlink" title=""\r\n\t\t\t\tonmouseover="vorschau\(\\\'ttfeatured\\\',true,\\\'(.+?)\s\(([\d]{4})\)').findall(link)
        for url,name,year in match:
                if 'season' in url:
                        addDir(name,url,17,'',None,year)
                else:
                        if EnableMeta == 'true':
                                addDir(name,url,16,'','tvshow',year)
                        if EnableMeta == 'false':
                                addDir(name,url,16,'',None,year)
#ACTORS
def ACTORS(url,name):
        dialog = 'Please wait while loading Actors list.'
        actor = name
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)" title="watch (.+?) online">').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create(dialog)
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Actors loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'',remaining_display)
        for url,name in match:
                if name.startswith(actor):
                        addDir(name,ALLUC_URL+url,50,'',None,'')
                loadedLinks = loadedLinks + 1
                percent = (loadedLinks * 100)/totalLinks
                remaining_display = 'Actors loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
                dialogWait.update(percent,'',remaining_display)
                if (dialogWait.iscanceled()):
                        return False
        dialogWait.close()
        del dialogWait
        
def ACTORSLINKS(url,name):
        EnableMeta = local.getSetting('Enable-Meta')
        dialog = 'Please wait while finding moves with:' +name
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('href="(.+?)" title="watch (.+?)\s\(([\d]{4})\) online"').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create(dialog)
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Movies loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'',remaining_display)
        for url,name,year in match:
                if EnableMeta == 'true':
                        addDir(name,ALLUC_URL+url,18,'','Movie',year)
                if EnableMeta == 'false':
                        addDir(name,ALLUC_URL+url,18,'',None,year)
                loadedLinks = loadedLinks + 1
                percent = (loadedLinks * 100)/totalLinks
                remaining_display = 'Movies loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
                dialogWait.update(percent,'',remaining_display)
                if (dialogWait.iscanceled()):
                        return False
        dialogWait.close()
        del dialogWait

#FORUMS
def FORUM(url):
        net.set_cookies(cookiejar)
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('',re.DOTALL).findall(link)
        for url,name in match:
               addDir(name,ALLUC_URL+url,20,'',None,None)
               
def FORUMSMOVIE(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)" class=" subject_new" id=".+?">(.+?)</a>').findall(link)#<a href="(.+?)" class=" subject_new" id=".+?">(.+?)\s\(([\d]{4})\)(.+?)</a>
        for url,name in match:
                nono = ['Non-english movie list thread (updated)','Trailer BBcode','IMDB BBcode tags', 'MOVIE LINKS PLEASE READ', 'Forum Rules: Movie Links']
                if name not in str(nono):
                        addDir(name,ALLUC_FORUMS+url,48,'',None,'')
        

def FORUMSTV(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)" class=" subject_new" id=".+?">(.+?)</a>').findall(link)
        for url,name in match:
                nono = ['Weekly WWE/TNA Shows & Monthly PPV','which sites can be linked?','Free Live tv from the world', 'Forum Rules: TV Links', 'Forum Rules: Movie Links', 'Important: Link-Hunters please read!', 'TV LINKS PLEASE READ']
                if name not in str(nono):
                        addDir(name,ALLUC_FORUMS+url,48,'',None,'')

def FORUMSDOC(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)" class=" subject_new" id=".+?">(.+?)</a>').findall(link)
        for url,name in match:
                nono = ['A List of Lists listing Documentaries','New Subforum ','BBC Horizon Collection (290+ Episodes)', 'Forum Rules: Documentaries']
                if name not in str(nono):
                        addDir(name,ALLUC_FORUMS+url,48,'',None,'')

def FORUMSLINKS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)" target="_blank">').findall(link)
        for url in match:
                name = url
                if 'sockshare' in url:
                        addDir(name,url,20,'',None,'')
                if 'movreel' in url:
                        addDir(name,url,20,'',None,'')
                if 'putlocker' in url:
                        addDir(name,url,20,'',None,'')
                if 'filenuke' in url:
                        addDir(name,url,20,'',None,'')
                if 'billionuploads' in url:
                        addDir(name,url,20,'',None,'')
                if 'movshare' in url:
                        addDir(name,url,20,'',None,'')
                if 'uploadc' in url:
                        addDir(name,url,20,'',None,'')
                if '180upload' in url:
                        addDir(name,url,20,'',None,'')
                if 'vidxden' in url:
                        addDir(name,url,20,'',None,'')
                if 'vidhog' in url:
                        addDir(name,url,20,'',None,'')
                if 'vidbux' in url:
                        addDir(name,url,20,'',None,'')
                

#Seasons
def SEASONS(url,name):
        EnableMeta = local.getSetting('Enable-Meta')
        if EnableMeta == 'true': dialog = 'Please wait while Metadata is added.'
        if EnableMeta == 'false': dialog = 'Please wait while Seasons list is created.'
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a class="linklist2 linklist_header" style="font-weight:bold;padding-left:2px; width:auto;margin-bottom:2px;" \r\n\t\t\t\thref="(.+?)" title="watch (.+?)\s\(([\d]{4})\)\s(.+?) online">').findall(link) #"watch (.+?)\s\(([\d]{4})\)\s(.+?) online"
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create(dialog)
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Seasons loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'',remaining_display)
        for url,name,year,seasons in match:
                addDir2("%s ~ %s"%(name,seasons),ALLUC_URL+url,17,'',None,year)
                loadedLinks = loadedLinks + 1
                percent = (loadedLinks * 100)/totalLinks
                remaining_display = 'Seasons loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
                dialogWait.update(percent,'',remaining_display)
                if (dialogWait.iscanceled()):
                        return False
        dialogWait.close()
        del dialogWait

#Episodes
def EPISODES(url,name):
        EnableMeta = local.getSetting('Enable-Meta')
        if EnableMeta == 'true': dialog = 'Please wait while Metadata is added.'
        if EnableMeta == 'false': dialog = 'Please wait while Episodes list is created.'
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a class="linklist2" style="font-weight:bold;padding-left:10px;width:auto;" \r\n\t\t\t\thref="(.+?)" title="watch (.+?) online">').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create(dialog)
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'',remaining_display)
        for url,name in match:
                addDir(name,ALLUC_URL+url,18,'',None,'')
                loadedLinks = loadedLinks + 1
                percent = (loadedLinks * 100)/totalLinks
                remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
                dialogWait.update(percent,'',remaining_display)
                if (dialogWait.iscanceled()):
                        return False
        dialogWait.close()
        del dialogWait

#Get Videolinks
def VIDEOLINKS(url):
        Enable_Streamcloud = local.getSetting('Enable-Streamcloud')
        arg = { 'x':'1'}
        encoded_arg = urllib.urlencode(arg)
        req = urllib2.Request(url, encoded_arg)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.2; en-GB; rv:1.8.1.18) Gecko/22082049 Firefox/2.0.0.18')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('[H](.+?)[L].+?\|(.+?)[U](.+?)[X]').findall(link)
        for name,desc,url in match:
                name = name.replace(']','')
                name = name.replace('[','')
                desc = desc.replace('[','')
                desc = desc.replace('[','')
                url = url.replace(']','')
                url = url.replace('[','')
                #List of allowed Hosters to show links for
                if Enable_Streamcloud == 'false':
                        hosters = ['billionuploads''Putlocker','Novamov','Sockshare','Filenuke','Movshare','Vidbux','Played','Movpod','Daclips','Movdivx','Flashx','Vidhog','Vidbull','Divxstage','Zalaa','Movreel','Sharerepo','Uploadc','Sharesix','Thefile','Watchfreeinhd','Videoweed','Vidxden','2gb-hosting']
                else:
                        hosters = ['Streamcloud','billionuploads''Putlocker','Novamov','Sockshare','Filenuke','Movshare','Vidbux','Played','Movpod','Daclips','Movdivx','Flashx','Vidhog','Vidbull','Divxstage','Zalaa','Movreel','Sharerepo','Uploadc','Sharesix','Thefile','Watchfreeinhd','Videoweed','Vidxden','2gb-hosting']
                if name in str(hosters):
                        addDir("%s : %s"%(name,desc),url,20,'',None,'')
               
#Final streaming url
def STREAM(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
        print streamlink
        addLink(name,streamlink,'')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok


def addDir(name,url,mode,iconimage,types,year):
        ok=True
        type = types
        if type != None:
                infoLabels = GRABMETA(name,types,year)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels) 
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir2(name,url,mode,iconimage,types,year):
        ok=True
        type = types
        if type != None:
                infoLabels = GRABMETA(name,types,year)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels) 
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
        
elif mode==1:
        MOVIES()

elif mode==2:
        MOVIESAZ()

elif mode==3:
        MOVIESGEN()

elif mode==4:
        TVSHOWS()

elif mode==5:
        ANIME()

elif mode==6:
        CARTOONS()

elif mode==7:
        DOCUMENTARIES()

elif mode==8:
        DOCUMENTARIESAZ()

elif mode==9:
        DOCUMENTARIESGEN()

elif mode==10:
        SPORTS()

elif mode==11:
        SPORTSAZ()

elif mode==12:
        SPORTSGEN()

elif mode==13:
        print ""+url
        INDEX1(url)
        
elif mode==14:
        print ""+url
        INDEX2(url)

elif mode==15:
        print ""+url
        INDEX3(url)

elif mode==16:
        print ""+url
        SEASONS(url,name)

elif mode==17:
        print ""+url
        EPISODES(url,name)

elif mode==18:
        print ""+url
        VIDEOLINKS(url)

elif mode==19:
        TVSHOWSAZ()

elif mode==20:
        print ""+url
        STREAM(url,name)

elif mode==21:
        ADULT()

elif mode==22:
        SEARCH()
        
elif mode==23:
        ADULTAZ()
        
elif mode==24:
        ADULTGEN()

elif mode==25:
        print ""+url
        FEATURED(url)

elif mode==26:
        print ""+url
        FEATUREDTV(url)
                                 
elif mode==27:
        print ""+url
        SIMILAR(url)

elif mode==28:
        SEARCHMOVIES()

elif mode==29:
        SEARCHTV()

elif mode==30:
        ANIMEAZ()

elif mode==31:
        SEARCHANIME()

elif mode==32:
        CARTOONSAZ()

elif mode==33:
        SEARCHCARTOON()

elif mode==34:
        SEARCHDOCUMENTARIES()

elif mode==35:
        SEARCHADULT()

elif mode==36:
        print ""+url
        FINDSID(url)

elif mode==37:
        print ""+url
        MESSAGES(url)

elif mode==38:
        print ""+url
        READMESSAGES(url)

elif mode==39:
        print ""+url
        OTHERWATCHLIST(url)

elif mode==40:
        print ""+url
        MYWATCHLIST(url)

elif mode==41:
        print ""+url
        FORUM(url)

elif mode==42:
        print ""+url
        UNRESTRICT(url)

elif mode==43:
        print ""+url
        UNCHECK(url)

elif mode==44:
        print ""+url
        FORUMS()

elif mode==45:
        print ""+url
        FORUMSMOVIE(url)

elif mode==46:
        print ""+url
        FORUMSTV(url)

elif mode==47:
        print ""+url
        FORUMSDOC(url)

elif mode==48:
        print ""+url
        FORUMSLINKS(url)

elif mode==49:
        print ""+url
        ACTORS(url,name)

elif mode==50:
        print ""+url
        ACTORSLINKS(url,name)

elif mode==51:
        print ""+url
        SEARCH(url)

elif mode==52:
        print ""+url
        UNTRY(url)

elif mode==53:
        ACTORSDIR()

elif mode==54:
        ACTORSAZ()

elif mode==55:
        ACTORSEARCH()

        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
