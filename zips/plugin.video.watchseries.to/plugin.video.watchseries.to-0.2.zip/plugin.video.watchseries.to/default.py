import urllib,urllib2,re,xbmcplugin,xbmcgui,urlresolver,xbmc,xbmcaddon,os
from metahandler import metahandlers
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net
import silent


#www.watchseries.to - by The_Silencer 2013 v0.2


grab = metahandlers.MetaData(preparezip = False)
addon_id = 'plugin.video.watchseries.to'
local = xbmcaddon.Addon(id=addon_id)
watchseriespath = local.getAddonInfo('path')
addon = Addon(addon_id, sys.argv)
datapath = addon.get_profile()
art = watchseriespath+'/art'
net = Net()
metaget = metahandlers.MetaData()

    
#Main menu
def CATEGORIES():
        addDir('Most Popular','http://watchseries.to/',1,'',None)
        addDir('Newest Episodes','http://watchseries.to/latest',16,'',None)
        addDir('Weeks Popular Episodes','http://www.watchseries.to/new',16,'',None)
        addDir('A-Z','http://watchseries.to/letters/A',13,'',None)
        addDir('Genres','http://watchseries.to/genres/drama',15,'',None)
        addDir('TV Schedule','http://www.watchseries.to/tvschedule/-1',18,'',None)
        addDir('Search','http://watchseries.to/',17,'',None)
        addDir('Favorites','http://watchseries.to/',19,'',None)

#Popular menu
def POPULAR():
        addDir('Popular this week','http://watchseries.to/new',2,'',None)
        addDir('Popular Series','http://watchseries.to/',6,'',None)
        addDir('Popular Cartoons','http://watchseries.to/',7,'',None)
        addDir('Popular Documentaries','http://watchseries.to/',8,'',None)
        addDir('Popular Shows','http://watchseries.to/',9,'',None)
        addDir('Popular Sports','http://watchseries.to/',10,'',None)

#Return Favorites List *temp need to fix in silent*
def GETMYFAVS():
        MYFAVS = silent.getFavorites()
        print MYFAVS
        for name,url,types in MYFAVS:
                addFAVDir(name,url,types)

#TV Schedule menu
def SCHEDULE(url):
        match=re.compile('<a href="(.+?)">(.+?)</a>').findall(net.http_GET(url).content)
        for url,name in match:
                ok = '/tvschedule/'
                nono = 'TV Schedule'
                if ok in url:
                        if name not in nono:
                                addDir(name,'http://watchseries.to'+url,16,'',None)
                        
#A-Z list
def AZ(url):
        match=re.compile('<a href="(.+?)">(.+?)</a></li>').findall(net.http_GET(url).content)
        for url,name in match:
                ok = ['09','A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z']
                if name in ok:
                        addDir(name,'http://watchseries.to'+url,14,'',None)

#Genres list
def GENRES(url):
        match=re.compile('<a href="(.+?)" class="sr-header" title=".+?">(.+?)</a>').findall(net.http_GET(url).content)
        for url,name in match:
                nono = ['Home', 'New Releases', 'Latest Added', 'Featured Movies', 'Latest HD Movies', 'Most Viewed', 'Most Viewed', 'Most Voted', 'Genres', 'Submit Links']
                if name not in nono:
                        addDir(name,'http://www.watchseries.to'+url,14,'',None)

#Search for Movies
def SEARCH(url):
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search WatchSeries.to')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                print encode
                url = 'http://www.watchseries.to/search/'+encode
                print url
                match=re.compile('<td valign="top" style="padding-left: 10px;">.+?<a href="(.+?)" title="(.+?)">',re.DOTALL).findall(net.http_GET(url).content) 
                for url,name in match:
                        name = silent.CLEAN(name)
                        if EnableMeta == 'true':
                               addDir(name,'http://watchseries.to'+url,11,'','tvshow')
                        if EnableMeta == 'false':
                               addDir(name,'http://watchseries.to'+url,11,'',None)

def LIST(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<li><a href="(.+?)" title=".+?">(.+?)<span class="epnum">(.+?)</span></a></li>').findall(net.http_GET(url).content)
        for url,name,year in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://watchseries.to'+url,11,'','tvshow')
                if EnableMeta == 'false':
                        addDir(name,'http://watchseries.to'+url,11,'',None)

def NEWLINKS(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<li><a href="(.+?)">(.+?) Seas. (.+?) Ep. (.+?) \(.+?\).+?</a></li>',re.DOTALL).findall(net.http_GET(url).content)
        for url,name,season,episode in match:
                nono = '</a>'
                name = silent.CLEAN(name)
                if nono not in name:
                        if EnableMeta == 'true':
                                addDir('%s - Seas. %s : Ep. %s' %(name,season,episode),'http://watchseries.to'+url+'@'+name+'@'+season+'@'+episode,3,'','new')
                        if EnableMeta == 'false':
                                addDir(name,'http://watchseries.to'+url,3,'',None)

def INDEX(url):
        EnableMeta = local.getSetting('Enable-Meta')
        data=re.compile('<ul class="listings">(.+?)</ul>',re.DOTALL).findall(net.http_GET(url).content)
        pattern = '<li><a href="(.+?)">(.+?) Seas..+?</a></li>'
        match = re.findall(pattern,str(data))
        for url,name in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://watchseries.to'+url,3,'','tvshow')
                if EnableMeta == 'false':
                        addDir(name,'http://watchseries.to'+url,3,'',None)

def INDEX2(url):
        EnableMeta = local.getSetting('Enable-Meta')
        data=re.compile('<img src=".+?"/>&nbsp;Most Popular Series\n\t\t\t\t</div>(.+?)</div>',re.DOTALL).findall(net.http_GET(url).content)
        pattern = '<a href="(.+?)" title="watch online (.+?)">.+?</a>'
        match = re.findall(pattern,str(data))
        for url,name in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://watchseries.to'+url,11,'','tvshow')
                if EnableMeta == 'false':
                        addDir(name,'http://watchseries.to'+url,11,'',None)

def INDEX3(url):
        EnableMeta = local.getSetting('Enable-Meta')
        data=re.compile('<img src=".+?"/>&nbsp;Most Popular Cartoons\n\t\t\t\t</div>(.+?)</div>',re.DOTALL).findall(net.http_GET(url).content)
        pattern = '<a href="(.+?)" title="watch online (.+?)">.+?</a>'
        match = re.findall(pattern,str(data))
        for url,name in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://watchseries.to'+url,11,'','tvshow')
                if EnableMeta == 'false':
                        addDir(name,'http://watchseries.to'+url,11,'',None)

def INDEX4(url):
        EnableMeta = local.getSetting('Enable-Meta')
        data=re.compile('<img src=".+?"/>&nbsp;Most Popular Documentaries\n\t\t\t\t</div>(.+?)</div>',re.DOTALL).findall(net.http_GET(url).content)
        pattern = '<a href="(.+?)" title="watch online (.+?)">.+?</a>'
        match = re.findall(pattern,str(data))
        for url,name in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://watchseries.to'+url,11,'','tvshow')
                if EnableMeta == 'false':
                        addDir(name,'http://watchseries.to'+url,11,'',None)

def INDEX5(url):
        EnableMeta = local.getSetting('Enable-Meta')
        data=re.compile('<img src=".+?"/>&nbsp;Most Popular Shows\n\t\t\t\t</div>(.+?)</div>',re.DOTALL).findall(net.http_GET(url).content)
        pattern = '<a href="(.+?)" title="watch online (.+?)">.+?</a>'
        match = re.findall(pattern,str(data))
        for url,name in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://watchseries.to'+url,11,'','tvshow')
                if EnableMeta == 'false':
                        addDir(name,'http://watchseries.to'+url,11,'',None)

def INDEX6(url):
        EnableMeta = local.getSetting('Enable-Meta')
        data=re.compile('<img src=".+?"/>&nbsp;Most Popular  Sports\n\t\t\t\t</div>(.+?)</div>',re.DOTALL).findall(net.http_GET(url).content)
        pattern = '<a href="(.+?)" title="watch online (.+?)">.+?</a>'
        match = re.findall(pattern,str(data))
        for url,name in match:
                name = silent.CLEAN(name)
                if EnableMeta == 'true':
                        addDir(name,'http://watchseries.to'+url,11,'','tvshow')
                if EnableMeta == 'false':
                        addDir(name,'http://watchseries.to'+url,11,'',None)

#Find Seasons for shows
def SEASONS(name,url):
        title = name
        match=re.compile('<h2 class="lists"><a href="(.+?)">(.+?)</h2>').findall(net.http_GET(url).content)
        for url,name in match:
                addDir(name,'http://watchseries.to'+url+'@'+title,12,'','seasons')

#Find Episodes for shows
def EPISODES(name,url):
        title = url.split('@')[1]
        url = url.split('@')[0]
        season = name
        match=re.compile('<li><a href="(.+?)"><span class="">(.+?)&nbsp;&nbsp;&nbsp;(.+?)</span><span class="epnum">(.+?)</span></a></li>').findall(net.http_GET(url).content)
        for url,episode,name,date in match:
                name = silent.CLEAN(name)
                addDir('%s    :    %s   :   %s' %(episode,date,name),'http://watchseries.to'+url+'@'+title+'@'+season+'@'+episode,3,'','new')

#First page with Hosters
def VIDEOLINKS(url):
        url = url.split('@')[0]
        match=re.compile('<a target="_blank" href="(.+?)" class="buttonlink" title="(.+?)" style="cursor:pointer;"').findall(net.http_GET(url).content)
        match2=re.compile('<p><strong>Sorry, there are no links available for this (.+?).</strong></p>').findall(net.http_GET(url).content)
        for url,name in match:
                addDir(name,'http://watchseries.to'+url,4,'',None)
        for name in match2:
                addDir('[B][COLOR yellow]Sorry, no links available yet[/COLOR][/B]','http://watchseries.to'+url,4,'',None)

#Get the Final Hoster link
def VIDEOLINKS2(name,url):
        match=re.compile('<a href="(.+?)" class="myButton">Click Here to Play</a>').findall(net.http_GET(url).content)
        for url in match:
                STREAM(name,url)

#Pass url to urlresolver
def STREAM(name,url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
        print streamlink
        url = streamlink
        addLink(name,streamlink,'')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok

def addDir(name,url,mode,iconimage,types):
        EnableFanArt = local.getSetting('Enable-Fanart')
        ok=True
        type = types
        fimg = addon.get_fanart()
        if type != None:
                infoLabels = silent.GRABMETA(name,url,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        if EnableFanArt == 'true':
                try:    fimg = infoLabels['backdrop_url']
                except: fimg = addon.get_fanart()
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        liz.setProperty( "Fanart_Image", fimg )
        contextMenuItems = []
        if mode == 11:
                contextMenuItems = []
                contextMenuItems.append(('Add to Favorites', 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
                liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addFAVDir(name,url,types):
        EnableFanArt = local.getSetting('Enable-Fanart')
        mode = 11
        iconimage = ''
        ok=True
        type = types
        fimg = addon.get_fanart()
        if type != None:
                infoLabels = silent.GRABMETA(name,url,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img = iconimage
        if EnableFanArt == 'true':
                try:    fimg = infoLabels['backdrop_url']
                except: fimg = addon.get_fanart()
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        liz.setProperty( "Fanart_Image", fimg )
        ###Add to Library Context Menu
        contextMenuItems = []
        contextMenuItems.append(('Remove from Favorites', 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ##############################
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
    
params=get_params()
url=None
name=None
mode=None
types=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        types=urllib.unquote_plus(params["types"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
        
elif mode==1:
        POPULAR()

elif mode==2:
        print ""+url
        INDEX(url)

elif mode==3:
        print ""+url
        VIDEOLINKS(url)

elif mode==4:
        print ""+url
        VIDEOLINKS2(name,url)

elif mode==5:
        print ""+url
        STREAM(name,url)

elif mode==6:
        print ""+url
        INDEX2(url)

elif mode==7:
        print ""+url
        INDEX3(url)

elif mode==8:
        print ""+url
        INDEX4(url)

elif mode==9:
        print ""+url
        INDEX5(url)

elif mode==10:
        print ""+url
        INDEX6(url)

elif mode==11:
        print ""+url
        SEASONS(name,url)

elif mode==12:
        print ""+url
        EPISODES(name,url)

elif mode==13:
        print ""+url
        AZ(url)

elif mode==14:
        print ""+url
        LIST(url)

elif mode==15:
        print ""+url
        GENRES(url)

elif mode==16:
        print ""+url
        NEWLINKS(url)

elif mode==17:
        print ""+url
        SEARCH(url)

elif mode==18:
        print ""+url
        SCHEDULE(url)

elif mode==19:
        print ""+url
        GETMYFAVS()

elif mode==20:
        print ""+url
        silent.addFavorite(name,url,types)

elif mode==21:
        print ""+url
        silent.removeFavorite(name,url,types)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
